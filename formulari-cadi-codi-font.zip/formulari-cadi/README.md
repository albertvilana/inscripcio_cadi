# Codi font del formulari Cadí Challenge

Inclou formulari, backoffice, servidor API, biblioteques compartides, esquema buit de base de dades, contracte OpenAPI, logotips públics i dependències.

No inclou fitxers .env, claus, credencials, dades de participants, bases de dades, fotos de llicències, logs, captures, historial Git ni fitxers interns de Replit. Les variables d'entorn només es referencien pel nom, sense valors. S'han exclòs les proves amb dades fictícies i claus de prova i el sandbox de disseny.

race-prices.json conté identificadors de tarifes històriques, no claus ni dades de participants. El lockfile conserva les metadades públiques dels paquets.

## Instal·lació
Requereix Node.js i pnpm. Executa `pnpm install --frozen-lockfile`.
Configura de manera segura i per separat PostgreSQL, Clerk, emmagatzematge i Redsys. No s'inclou cap credencial ni accés a les dades originals.

Ordres (terminals separats):
- API: `PORT=8080 pnpm --filter @workspace/api-server run dev`
- Formulari: `PORT=21685 BASE_PATH=/ pnpm --filter @workspace/inscripcion-carrera-bici run dev`
- Tipus: `pnpm run typecheck`

Cal un proxy que encamini /api al servidor API i configurar els serveis externs. Les integracions d'autenticació i emmagatzematge de Replit poden requerir adaptació fora de Replit.
Mantén REDSYS_ENABLED=false fins que la configuració del banc i les notificacions s'hagin verificat.

És una exportació de codi font, no una còpia de dades ni un desplegament autònom preconfigurat.
