import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ClerkProvider, SignIn, SignUp, useAuth } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { esES } from '@clerk/localizations';
import {
  ArrowLeft,
  ArrowRight,
  BadgeCheck,
  Bike,
  BedDouble,
  CalendarDays,
  Check,
  CircleAlert,
  FileCheck2,
  LockKeyhole,
  Mail,
  Mars,
  MapPin,
  Mountain,
  RefreshCw,
  ShieldCheck,
  Shirt,
  Upload,
  UserRound,
  Venus,
} from 'lucide-react';
import {
  getGetRaceQueryKey,
  getGetRegistrationPaymentQueryKey,
  useCreateCheckoutSession,
  useCreateRegistration,
  useGetRace,
  useGetRegistrationPayment,
  type Race,
  type RaceOption,
  type Registration,
  type RegistrationInput,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import OrganizerPage from '@/components/OrganizerPage';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Route, Router as WouterRouter, Switch, useLocation } from 'wouter';
import BackofficePage from '@/pages/BackofficePage';
import DiscountCodeField from '@/components/DiscountCodeField';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
if (!clerkPubKey) throw new Error('No se ha configurado el acceso a la subida privada de licencias.');

type FormState = Omit<RegistrationInput, 'jerseyCut' | 'jerseySize' | 'hasCyclingLicense'> & {
  hasCyclingLicense: boolean | null;
  jerseyCut: RegistrationInput['jerseyCut'] | '';
  jerseySize: RegistrationInput['jerseySize'] | '';
};

const jerseySizes: RegistrationInput['jerseySize'][] = ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL'];

const initialForm: FormState = {
  firstName: '',
  lastName: '',
  email: '',
  phone: '',
  birthDate: '',
  nationality: '',
  accommodation: 'none',
  hasCyclingLicense: null,
  licensePhotoPath: null,
  cancellationInsurance: false,
  jerseyCut: '',
  jerseySize: '',
  notes: '',
  termsAccepted: false,
  marketingAccepted: false,
};

function loadDraft(): FormState {
  try {
    const saved = window.sessionStorage.getItem('carrera-form-draft');
    if (saved) {
      const draft = JSON.parse(saved) as Partial<FormState>;
      return { ...initialForm, ...draft, termsAccepted: false };
    }
  } catch {
    // A fresh registration remains available when session storage is blocked.
  }
  return initialForm;
}

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
}

type FormErrors = Partial<Record<keyof FormState, string>>;
type ReturnState = 'success' | 'cancelled' | null;

function formatPrice(value: number, currency = 'EUR') {
  return new Intl.NumberFormat('es-ES', {
    style: 'currency',
    currency: currency.toUpperCase(),
  }).format(value);
}

function getErrorText(error: unknown) {
  if (error && typeof error === 'object') {
    const candidate = error as { data?: { error?: string }; response?: { data?: { error?: string } }; message?: string };
    return candidate.data?.error ?? candidate.response?.data?.error ?? candidate.message ?? 'Ha ocurrido un error inesperado.';
  }
  return 'Ha ocurrido un error inesperado.';
}

function getOptionPrice(race: Race, matcher: (option: RaceOption) => boolean) {
  return race.options.find(matcher)?.price ?? 0;
}

function getReturnState(): ReturnState {
  const params = new URLSearchParams(window.location.search);
  const status = params.get('payment') ?? params.get('status');
  if (status === 'success') return 'success';
  if (status === 'cancelled' || status === 'cancel' || status === 'canceled') return 'cancelled';
  if (params.has('session_id')) return 'success';
  return null;
}

function LoadingState() {
  return (
    <div className="race-app">
      <div className="topbar">
        <div className="brand-lockup" aria-label="Inscripción Carrera de Bicis">
          <span className="brand-mark"><Bike size={21} strokeWidth={2.2} /></span>
               <span><span className="brand-name">Inscripción Carrera</span><span className="brand-caption">de bicis · edición abierta</span></span>
        </div>
      </div>
      <main className="empty-state" aria-live="polite" data-testid="state-loading-race">
        <div className="loading-card">
          <div className="skeleton large" />
          <div className="skeleton short" />
          <div className="skeleton" />
          <div className="skeleton" style={{ marginTop: '0.7rem' }} />
          <p className="sr-only">Cargando los detalles de la carrera</p>
        </div>
      </main>
    </div>
  );
}

function RaceUnavailable({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="race-app">
      <div className="topbar">
        <div className="brand-lockup" aria-label="Inscripción Carrera de Bicis">
          <span className="brand-mark"><Bike size={21} strokeWidth={2.2} /></span>
           <span><span className="brand-name">Inscripción Carrera</span><span className="brand-caption">de bicis · edición abierta</span></span>
        </div>
      </div>
      <main className="empty-state" data-testid="state-error-race">
        <div>
          <div className="empty-icon"><CircleAlert size={28} /></div>
          <h2>No podemos mostrar la carrera todavía</h2>
          <p>La información de inscripción no ha respondido. Comprueba tu conexión y vuelve a intentarlo.</p>
          <button className="button button-primary" type="button" onClick={onRetry} data-testid="button-retry-race">
            <RefreshCw size={16} /> Reintentar
          </button>
        </div>
      </main>
    </div>
  );
}

function PendingState({ state, onReturn }: { state: Exclude<ReturnState, null>; onReturn: () => void }) {
  const savedRegistration = useMemo(() => {
    try {
      const raw = window.sessionStorage.getItem('carrera-registration');
      return raw ? JSON.parse(raw) as Registration : null;
    } catch {
      return null;
    }
  }, []);
  const reference = new URLSearchParams(window.location.search).get('registration') ?? savedRegistration?.id ?? '';
  const validReference = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(reference);
  const [pollingUntil] = useState(() => Date.now() + 60000);
  const payment = useGetRegistrationPayment(reference, { query: {
    queryKey: getGetRegistrationPaymentQueryKey(reference),
    enabled: validReference,
    retry: false,
    refetchInterval: (query) => query.state.data?.status === 'paid' || Date.now() > pollingUntil ? false : 3000,
    staleTime: 0,
  } });
  const confirmed = payment.data?.status === 'paid' &&
    payment.data.paidTotalCents !== null &&
    payment.data.paidTotalCents === payment.data.orderTotalCents;
  const declined = !confirmed && payment.data?.status === 'cancelled';
  useEffect(() => {
    if (!confirmed) return;
    try {
      window.sessionStorage.removeItem('carrera-registration');
      window.sessionStorage.removeItem('carrera-form-draft');
    } catch { /* A receipt still works without session storage. */ }
  }, [confirmed]);

  return (
    <div className="race-app noise">
      <div className="pending-shell">
        <section className="pending-card" aria-live="polite" data-testid={`state-checkout-${state}`}>
          <div className="pending-icon">
            {confirmed ? <BadgeCheck size={30} /> : <CircleAlert size={30} />}
          </div>
          <span className="eyebrow">{confirmed ? 'Pago confirmado por Redsys' : declined ? 'Pago no autorizado' : 'Pago pendiente de verificación'}</span>
          <h1>{confirmed ? 'Tu inscripción está confirmada' : declined ? 'Tu inscripción sigue guardada' : 'Estamos comprobando tu pago'}</h1>
          <p>
            {confirmed
              ? 'Hemos recibido la confirmación segura del banco. Tu plaza está registrada y pagada.'
              : declined
                ? 'Redsys no ha autorizado esta operación. Puedes volver al formulario para reintentar el pago.'
                : 'Volver de la pasarela no confirma el pago. Espera a la confirmación del banco y no repitas el pago si ya lo has autorizado.'}
          </p>
          {validReference && (
            <div className="pending-details">
              <div className="pending-detail"><span>Referencia</span><strong data-testid="text-registration-id">{reference}</strong></div>
              {payment.data?.orderTotalCents != null && <div className="pending-detail"><span>Importe</span><strong data-testid="text-registration-total">{formatPrice(payment.data.orderTotalCents / 100)}</strong></div>}
            </div>
          )}
          {payment.isError && <p role="alert">No hemos podido consultar el estado del pago. No vuelvas a pagar sin verificarlo con la organización.</p>}
          {!validReference && <p role="alert">No encontramos la referencia de tu inscripción. Contacta con la organización antes de volver a pagar.</p>}
          {validReference && !confirmed && <button className="button button-secondary" type="button" onClick={() => void payment.refetch()} disabled={payment.isFetching}>Actualizar estado</button>}
          <button className="button button-primary" type="button" onClick={onReturn} data-testid="button-return-registration">
            {declined ? 'Retomar inscripción' : 'Volver al formulario'} <ArrowRight size={16} />
          </button>
        </section>
      </div>
    </div>
  );
}

function NotFoundState() {
  return (
    <div className="race-app noise">
      <div className="pending-shell">
        <section className="pending-card" data-testid="state-not-found">
          <div className="pending-icon"><CircleAlert size={30} /></div>
          <span className="eyebrow">Desvío de ruta · 404</span>
          <h1>Esta página no está en el recorrido.</h1>
          <p>La dirección que buscas no existe o ya ha cambiado. Vuelve al punto de partida para continuar con tu inscripción.</p>
          <a className="button button-primary" href="/" data-testid="link-return-home">Volver a la inscripción <ArrowRight size={16} /></a>
        </section>
      </div>
    </div>
  );
}

function Stepper({ step }: { step: number }) {
  return (
    <div className="stepper" aria-label="Progreso de inscripción">
      {['Tus datos', 'Tu experiencia', 'Confirmación'].map((label, index) => {
        const number = index + 1;
        const state = number < step ? 'is-complete' : number === step ? 'is-active' : '';
        return <div className={`stepper-item ${state}`} key={label}><span className="stepper-index">0{number}</span>{label}</div>;
      })}
    </div>
  );
}

function SummaryCard({ race, form, discountAmount }: {
  race: Race;
  form: Pick<FormState, 'accommodation' | 'hasCyclingLicense' | 'cancellationInsurance' | 'discountCode'>;
  discountAmount: number;
}) {
  const currency = race.currency ?? 'EUR';
  const saturdayPrice = getOptionPrice(race, (option) => option.id === 'accommodation-saturday' || `${option.kind ?? ''} ${option.label}`.toLowerCase().includes('sábado'));
  const sundayPrice = getOptionPrice(race, (option) => option.id === 'accommodation-sunday' || `${option.kind ?? ''} ${option.label}`.toLowerCase().includes('domingo'));
  const temporaryLicensePrice = getOptionPrice(race, (option) => option.id === 'temporary-license');
  const cancellationPrice = getOptionPrice(race, (option) => {
    const text = `${option.kind ?? ''} ${option.label}`.toLowerCase();
    return text.includes('cancel') || text.includes('anul');
  });
  const hasSaturday = form.accommodation === 'saturday' || form.accommodation === 'both';
  const hasSunday = form.accommodation === 'sunday' || form.accommodation === 'both';
  const accommodationPrice = (hasSaturday ? saturdayPrice : 0) + (hasSunday ? sundayPrice : 0);
  const subtotal = race.basePrice + accommodationPrice + (form.hasCyclingLicense === false ? temporaryLicensePrice : 0) + (form.cancellationInsurance ? cancellationPrice : 0);
  const appliedDiscount = Math.min(discountAmount, subtotal);
  const total = Math.max(0, Math.round(subtotal * 100) - Math.round(appliedDiscount * 100)) / 100;
  const lines = [
    { label: 'Dorsal · dos etapas', price: race.basePrice },
    ...(hasSaturday ? [{ label: 'Alojamiento y pensión completa · sábado 5', price: saturdayPrice }] : []),
    ...(hasSunday ? [{ label: 'Alojamiento y pensión completa · domingo 6', price: sundayPrice }] : []),
    ...(form.hasCyclingLicense === false ? [{ label: 'Licencia temporal · dos días', price: temporaryLicensePrice }] : []),
    ...(form.cancellationInsurance ? [{ label: 'Seguro de cancelación', price: cancellationPrice }] : []),
    ...(form.discountCode && appliedDiscount > 0 ? [{ label: `Descuento · ${form.discountCode}`, price: -appliedDiscount }] : []),
  ];

  return (
    <aside className="summary-card" aria-label="Resumen de inscripción" data-testid="card-price-summary">
      <div className="summary-inner">
        <span className="summary-kicker">Tu dorsal empieza aquí</span>
        <h2 className="summary-title">{race.name}</h2>
        <div className="summary-meta">
          <div className="summary-meta-row"><CalendarDays size={15} /><span>{race.dates}</span></div>
          <div className="summary-meta-row"><MapPin size={15} /><span>{race.location}</span></div>
          <div className="summary-meta-row"><Mountain size={15} /><span>{race.edition}</span></div>
        </div>
        <div className="summary-breakdown">
          {lines.map((line) => <div className="summary-line" key={line.label}><span>{line.label}</span><strong>{formatPrice(line.price, currency)}</strong></div>)}
        </div>
        <div className="summary-total"><span>Total estimado</span><strong data-testid="text-live-total">{formatPrice(total, currency)}</strong></div>
        <p className="summary-note">{race.registrationStatus === 'paused' ? 'Vista previa: puedes consultar los precios, pero no enviar la inscripción ni pagar. Los pagos están desactivados en esta vista.' : 'El precio final se confirma antes de iniciar el pago. No se realizará ningún cargo en este paso.'}</p>
        <div className="summary-secure"><LockKeyhole size={14} /> {race.registrationStatus === 'paused' ? 'Envío y pago bloqueados' : 'Pago seguro'}</div>
      </div>
    </aside>
  );
}

function RegistrationFlow({ race }: { race: Race }) {
  const paymentsPaused = race.registrationStatus === 'paused';
  const [form, setForm] = useState<FormState>(loadDraft);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [step, setStep] = useState(1);
  const [errors, setErrors] = useState<FormErrors>({});
  const [registration, setRegistration] = useState<Registration | null>(() => {
    try {
      const saved = window.sessionStorage.getItem('carrera-registration');
      return saved ? JSON.parse(saved) as Registration : null;
    } catch { return null; }
  });
  const [checkoutError, setCheckoutError] = useState('');
  const [uploadError, setUploadError] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const { isLoaded: isAuthLoaded, isSignedIn } = useAuth();
  const createRegistration = useCreateRegistration();
  const createCheckoutSession = useCreateCheckoutSession();
  const currency = race.currency ?? 'EUR';

  useEffect(() => {
    document.title = `${race.name} · Inscripción Carrera de Bicis`;
  }, [race.name]);

  useEffect(() => {
    if (paymentsPaused) return;
    try {
      window.sessionStorage.setItem('carrera-form-draft', JSON.stringify(form));
    } catch {
      // The registration still works without draft persistence.
    }
  }, [form, paymentsPaused]);

  const updateField = <K extends keyof FormState>(field: K, value: FormState[K]) => {
    setForm((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
    if (registration) {
      setRegistration(null);
      try {
        window.sessionStorage.removeItem('carrera-registration');
      } catch {
        // Registration can still be recreated when session storage is unavailable.
      }
    }
  };

  const validateStep = (targetStep: number) => {
    const nextErrors: FormErrors = {};
    if (targetStep === 1) {
      if (!form.firstName.trim()) nextErrors.firstName = 'Indica tu nombre.';
      if (!form.lastName.trim()) nextErrors.lastName = 'Indica tus apellidos.';
      if (!form.email.trim() || !/^\S+@\S+\.\S+$/.test(form.email)) nextErrors.email = 'Escribe un email válido.';
      if (form.phone.trim().length < 7) nextErrors.phone = 'Necesitamos un teléfono válido.';
      if (!form.birthDate) nextErrors.birthDate = 'Indica tu fecha de nacimiento.';
      if (form.nationality.trim().length < 2) nextErrors.nationality = 'Indica tu nacionalidad.';
      if (form.hasCyclingLicense === null) nextErrors.hasCyclingLicense = 'Indica si dispones de licencia de ciclismo.';
      if (form.hasCyclingLicense && !isSignedIn) nextErrors.licensePhotoPath = 'Inicia sesión para subir la foto de tu licencia.';
      else if (form.hasCyclingLicense && !form.licensePhotoPath) nextErrors.licensePhotoPath = 'Adjunta una foto de tu licencia.';
      if (isUploading) nextErrors.licensePhotoPath = 'Espera a que termine la subida de la foto.';
    }
    if (targetStep === 2) {
      if (!form.jerseyCut) nextErrors.jerseyCut = 'Elige el modelo de maillot.';
      if (!form.jerseySize) nextErrors.jerseySize = 'Elige una talla.';
    }
    if (targetStep === 3 && !form.termsAccepted) nextErrors.termsAccepted = 'Debes aceptar las condiciones para continuar.';
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const startCheckout = (createdRegistration: Registration) => {
    if (paymentsPaused) {
      setCheckoutError('Los pagos están desactivados en esta vista previa.');
      return;
    }
    setCheckoutError('');
    createCheckoutSession.mutate({ data: { registrationId: createdRegistration.id } }, {
      onSuccess: (session) => {
        const allowedUrls = ['https://sis.redsys.es/sis/realizarPago', 'https://sis-t.redsys.es:25443/sis/realizarPago'];
        if (!allowedUrls.includes(session.checkoutUrl) || !session.formFields) {
          setCheckoutError('El proveedor de pago no ha devuelto una dirección segura. Tu inscripción está guardada; inténtalo de nuevo en unos minutos.');
          return;
        }
        const paymentForm = document.createElement('form');
        paymentForm.method = 'POST';
        paymentForm.action = session.checkoutUrl;
        paymentForm.target = '_top';
        for (const [name, value] of Object.entries(session.formFields)) {
          const input = document.createElement('input');
          input.type = 'hidden';
          input.name = name;
          input.value = value;
          paymentForm.appendChild(input);
        }
        document.body.appendChild(paymentForm);
        paymentForm.submit();
      },
      onError: (error) => setCheckoutError(`No hemos podido abrir el pago seguro. ${getErrorText(error)} Tu formulario sigue visible y tu inscripción está guardada.`),
    });
  };

  const submitRegistration = () => {
    if (paymentsPaused) {
      setCheckoutError('Esta vista previa no permite enviar inscripciones ni pagar.');
      return;
    }
    if (!validateStep(3)) return;
    if (form.hasCyclingLicense === null || (form.hasCyclingLicense && (!isSignedIn || !form.licensePhotoPath || isUploading))) {
      setStep(1);
      setErrors({ hasCyclingLicense: form.hasCyclingLicense === null ? 'Indica si dispones de licencia.' : undefined, licensePhotoPath: form.hasCyclingLicense && !form.licensePhotoPath ? 'Adjunta una foto de tu licencia.' : undefined });
      return;
    }
    if (!form.jerseyCut || !form.jerseySize) {
      setStep(2);
      setErrors({
        jerseyCut: form.jerseyCut ? undefined : 'Elige el modelo de maillot.',
        jerseySize: form.jerseySize ? undefined : 'Elige una talla.',
      });
      return;
    }
    setCheckoutError('');
    if (registration) {
      startCheckout(registration);
      return;
    }
    createRegistration.mutate({ data: { ...form, hasCyclingLicense: form.hasCyclingLicense, jerseyCut: form.jerseyCut, jerseySize: form.jerseySize } }, {
      onSuccess: (createdRegistration) => {
        setRegistration(createdRegistration);
        try {
          window.sessionStorage.setItem('carrera-registration', JSON.stringify(createdRegistration));
        } catch {
          // Session storage may be unavailable in private browsing; checkout still works.
        }
        startCheckout(createdRegistration);
      },
      onError: (error) => setCheckoutError(`No hemos podido guardar tu inscripción. ${getErrorText(error)}`),
    });
  };

  const saturdayOption = race.options.find((option) => option.id === 'accommodation-saturday' || `${option.kind ?? ''} ${option.label}`.toLowerCase().includes('sábado'));
  const sundayOption = race.options.find((option) => option.id === 'accommodation-sunday' || `${option.kind ?? ''} ${option.label}`.toLowerCase().includes('domingo'));
  const temporaryLicenseOption = race.options.find((option) => option.id === 'temporary-license');
  const cancellationOption = race.options.find((option) => {
    const text = `${option.kind ?? ''} ${option.label}`.toLowerCase();
    return text.includes('cancel') || text.includes('anul');
  });
  const isSubmitting = createRegistration.isPending || createCheckoutSession.isPending;
  const selectLicense = (hasLicense: boolean) => {
    updateField('hasCyclingLicense', hasLicense);
    updateField('licensePhotoPath', null);
    setUploadError('');
  };

  const uploadLicensePhoto = async (file?: File) => {
    if (paymentsPaused) {
      setUploadError('La subida de fotos está desactivada durante la vista previa.');
      return;
    }
    if (!file) return;
    setUploadError('');
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 5 * 1024 * 1024 || file.size === 0) {
      setUploadError('Elige una foto JPG, PNG o WebP de hasta 5 MB.');
      return;
    }
    setIsUploading(true);
    updateField('licensePhotoPath', null);
    try {
      const request = await fetch('/api/storage/uploads/request-url', {
        method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: file.name, size: file.size, contentType: file.type }),
      });
      const upload = await request.json() as { uploadURL?: string; objectPath?: string; error?: string };
      if (!request.ok || !upload.uploadURL || !upload.objectPath) throw new Error(upload.error ?? 'No se ha podido preparar la subida.');
      const put = await fetch(upload.uploadURL, { method: 'PUT', headers: { 'Content-Type': file.type }, body: file });
      if (!put.ok) throw new Error('La foto no se ha podido subir. Inténtalo de nuevo.');
      const confirmation = await fetch('/api/storage/uploads/confirm', {
        method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ objectPath: upload.objectPath }),
      });
      const confirmed = await confirmation.json() as { objectPath?: string; error?: string };
      if (!confirmation.ok || !confirmed.objectPath) throw new Error(confirmed.error ?? 'No se ha podido confirmar la foto.');
      updateField('licensePhotoPath', confirmed.objectPath);
    } catch (error) {
      setUploadError(error instanceof Error ? error.message : 'No se ha podido subir la foto.');
    } finally {
      setIsUploading(false);
    }
  };
  const toggleAccommodation = (day: 'saturday' | 'sunday') => {
    const selected = new Set<'saturday' | 'sunday'>(
      form.accommodation === 'both'
        ? ['saturday', 'sunday']
        : form.accommodation === 'none'
          ? []
          : [form.accommodation],
    );
    if (selected.has(day)) selected.delete(day);
    else selected.add(day);
    const nextAccommodation = selected.size === 2
      ? 'both'
      : selected.size === 1
        ? [...selected][0]
        : 'none';
    updateField('accommodation', nextAccommodation);
  };
  const accommodationLabel = form.accommodation === 'none'
    ? 'Sin alojamiento'
    : form.accommodation === 'both'
      ? 'Sábado 5 y domingo 6 · pensión completa'
      : form.accommodation === 'saturday'
        ? 'Sábado 5 · pensión completa'
        : 'Domingo 6 · pensión completa';

  return (
    <div className="race-app noise">
      <header className="cadi-head">
        <div className="cadi-head-bar">
          <span className="cadi-head-edition">{race.edition}</span>
        </div>
        <div className="cadi-head-hero">
          <nav className="cadi-crumbs" aria-label="Ruta de navegación">
            <a href={`${basePath}/`} data-testid="link-breadcrumb-home">Inicio</a>
            <span aria-hidden="true">/</span>
            <span aria-current="page">Inscripción</span>
          </nav>
          <h1 className="cadi-head-title">
            <span>Inscripción</span>
            <em>{race.dates}</em>
          </h1>
          <p className="cadi-head-sub">
            {race.location} · {race.edition} · {race.tagline ?? 'Dos días de ciclismo'} · Desde {formatPrice(race.basePrice, currency)}
          </p>
        </div>
      </header>

      <main className="main-layout">
        {paymentsPaused && <div className="registration-preview-notice" role="status" data-testid="state-registration-preview"><CircleAlert size={20} aria-hidden="true" /><div><strong>Formulario en vista previa</strong><p>Puedes recorrer los tres pasos y consultar las opciones y los precios. Esta vista no permite enviar inscripciones, subir fotos ni realizar pagos.</p></div></div>}
        <section className="form-column" aria-labelledby="registration-heading">
          <div className="form-intro">
            <div>
              <span className="eyebrow">{paymentsPaused ? 'Vista previa del formulario' : 'Reserva tu plaza'}</span>
              <h2 className="section-title" id="registration-heading">{step === 1 ? 'Empezamos por ti.' : step === 2 ? 'Prepara tu carrera.' : 'Repasa y confirma.'}</h2>
              <p className="section-subtitle">{step === 1 ? 'Solo lo necesario para preparar tu dorsal y mantenerte informado.' : step === 2 ? 'Elige lo que necesitas para llegar a la salida con todo resuelto.' : paymentsPaused ? 'Revisa el resumen. El envío y el pago están desactivados.' : 'Comprueba que todo está correcto antes de pasar al pago seguro.'}</p>
            </div>
            <span className="step-count">Paso 0{step} / 03</span>
          </div>
          <Stepper step={step} />

          {checkoutError && <div className="error-banner" role="alert" data-testid="alert-checkout-error"><CircleAlert size={17} /> <span>{checkoutError}</span></div>}

          <div className="form-panel">
            {step === 1 && (
              <>
                <section className="form-section">
                  <div className="section-heading"><div className="section-icon"><UserRound size={18} /></div><div><h3>Datos del participante</h3><p>Los usaremos para tu dorsal y las comunicaciones de carrera.</p></div></div>
                  <div className="field-grid">
                    <Field label="Nombre" required error={errors.firstName}><input value={form.firstName} onChange={(event) => updateField('firstName', event.target.value)} autoComplete="given-name" data-testid="input-first-name" aria-invalid={Boolean(errors.firstName)} /></Field>
                    <Field label="Apellidos" required error={errors.lastName}><input value={form.lastName} onChange={(event) => updateField('lastName', event.target.value)} autoComplete="family-name" data-testid="input-last-name" aria-invalid={Boolean(errors.lastName)} /></Field>
                    <Field label="Email" required error={errors.email}><input type="email" value={form.email} onChange={(event) => updateField('email', event.target.value)} autoComplete="email" placeholder="tu@email.com" data-testid="input-email" aria-invalid={Boolean(errors.email)} /></Field>
                    <Field label="Teléfono" required error={errors.phone}><input type="tel" value={form.phone} onChange={(event) => updateField('phone', event.target.value)} autoComplete="tel" placeholder="+34 600 000 000" data-testid="input-phone" aria-invalid={Boolean(errors.phone)} /></Field>
                    <Field label="Fecha de nacimiento" required error={errors.birthDate}><input type="date" value={form.birthDate} onChange={(event) => updateField('birthDate', event.target.value)} data-testid="input-birth-date" aria-invalid={Boolean(errors.birthDate)} /></Field>
                    <Field label="Nacionalidad" required error={errors.nationality}><input value={form.nationality} onChange={(event) => updateField('nationality', event.target.value)} autoComplete="country-name" placeholder="España" data-testid="input-nationality" aria-invalid={Boolean(errors.nationality)} /></Field>
                  </div>
                  <div className="license-question">
                    <h4 id="license-heading">¿Dispones de licencia de ciclismo? <span className="required">*</span></h4>
                    <div className="choice-grid license-choices" role="group" aria-labelledby="license-heading">
                      <ChoiceCard name="cycling-license" value="yes" checked={form.hasCyclingLicense === true} onChange={() => selectLicense(true)} title="Sí, tengo licencia" detail="Adjunta una foto para verificarla." price="Sin coste adicional" testId="choice-license-yes" />
                      <ChoiceCard name="cycling-license" value="no" checked={form.hasCyclingLicense === false} onChange={() => selectLicense(false)} title="No tengo licencia" detail="Añadiremos una licencia temporal para los dos días." price={`+ ${formatPrice(temporaryLicenseOption?.price ?? 25, currency)}`} testId="choice-license-no" />
                    </div>
                    {errors.hasCyclingLicense && <span className="field-error" role="alert">{errors.hasCyclingLicense}</span>}
                    {form.hasCyclingLicense === true && (
                      <div className="license-upload">
                        {paymentsPaused ? <><label htmlFor="license-photo"><Upload size={18} /> Foto de tu licencia de ciclismo</label><input id="license-photo" type="file" accept="image/jpeg,image/png,image/webp" disabled data-testid="input-license-photo" /><p>La subida de fotos está desactivada durante esta vista previa. No necesitas adjuntar una foto ni iniciar sesión para revisar los siguientes pasos.</p></> : !isAuthLoaded ? <p>Comprobando acceso para subir la licencia…</p> : !isSignedIn ? (
                          <p>Para proteger tu foto, inicia sesión antes de subirla. <a href={`${basePath}/sign-in`} data-testid="link-license-sign-in">Iniciar sesión para adjuntar mi licencia</a></p>
                        ) : (
                          <>
                            <label htmlFor="license-photo"><Upload size={18} /> Foto de tu licencia de ciclismo *</label>
                            <input id="license-photo" type="file" accept="image/jpeg,image/png,image/webp" disabled={isUploading} onChange={(event) => { void uploadLicensePhoto(event.target.files?.[0]); }} data-testid="input-license-photo" />
                            <span className="license-hint">JPG, PNG o WebP · máximo 5 MB. Tu foto es privada; tú y el equipo organizador autorizado podréis consultarla para revisar tu licencia. Si no terminas la inscripción, eliminaremos la foto pasadas 24 horas desde que caduque el enlace de subida.</span>
                            {isUploading && <span role="status">Subiendo y verificando la foto…</span>}
                            {form.licensePhotoPath && !isUploading && <span className="license-success" role="status"><Check size={15} /> Foto adjuntada correctamente</span>}
                            {uploadError && <span className="field-error" role="alert">{uploadError}</span>}
                          </>
                        )}
                        {errors.licensePhotoPath && <span className="field-error" role="alert">{errors.licensePhotoPath}</span>}
                      </div>
                    )}
                  </div>
                </section>
              </>
            )}

            {step === 2 && (
              <>
                <section className="form-section">
                   <div className="section-heading"><div className="section-icon"><BedDouble size={18} /></div><div><h3>Alojamiento y pensión completa</h3><p>Selecciona una o las dos noches de la carrera.</p></div></div>
                  <div className="choice-grid">
                     <ChoiceCard name="accommodation" value="none" checked={form.accommodation === 'none'} onChange={() => updateField('accommodation', 'none')} title="Voy por mi cuenta" detail="Sin alojamiento" price="Incluido" testId="choice-accommodation-none" />
                     <ChoiceCard name="accommodation-saturday" value="saturday" inputType="checkbox" checked={form.accommodation === 'saturday' || form.accommodation === 'both'} onChange={() => toggleAccommodation('saturday')} title="Sábado 5 de junio" detail={saturdayOption?.description ?? 'Consultar condiciones'} price={saturdayOption ? `+ ${formatPrice(saturdayOption.price, currency)}` : 'Consultar'} testId="choice-accommodation-saturday" />
                     <ChoiceCard name="accommodation-sunday" value="sunday" inputType="checkbox" checked={form.accommodation === 'sunday' || form.accommodation === 'both'} onChange={() => toggleAccommodation('sunday')} title="Domingo 6 de junio" detail={sundayOption?.description ?? 'Consultar condiciones'} price={sundayOption ? `+ ${formatPrice(sundayOption.price, currency)}` : 'Consultar'} testId="choice-accommodation-sunday" />
                  </div>
                </section>
                <section className="form-section">
                  <div className="section-heading"><div className="section-icon"><ShieldCheck size={18} /></div><div><h3>Capa extra de tranquilidad</h3><p>Opcional, para que la logística no te quite piernas.</p></div></div>
                  <div className="toggle-list">
                    <ToggleRow icon={<CalendarDays size={17} />} title="Seguro de cancelación" detail="Recupera el importe íntegramente hasta 2 meses antes de participar y el 50% hasta 2 semanas antes de empezar." checked={form.cancellationInsurance} onChange={(checked) => updateField('cancellationInsurance', checked)} price={cancellationOption ? `+ ${formatPrice(cancellationOption.price, currency)}` : 'Consultar'} testId="toggle-cancellation-insurance" />
                  </div>
                </section>
                <section className="form-section">
                  <div className="section-heading"><div className="section-icon"><Shirt size={18} /></div><div><h3 id="jersey-heading">Tu equipación</h3><p>Elige el modelo de maillot y, debajo, su talla.</p></div></div>
                  <div className="jersey-grid" role="group" aria-labelledby="jersey-heading">
                    {([
                      { cut: 'men', label: 'Hombre', Icon: Mars },
                      { cut: 'women', label: 'Mujer', Icon: Venus },
                    ] as const).map(({ cut, label, Icon }) => (
                      <div className="jersey-option" key={cut}>
                        <label className={`jersey-option-choice ${form.jerseyCut === cut ? 'is-selected' : ''}`} data-testid={`choice-jersey-${cut}`}>
                          <input
                            type="radio"
                            name="jersey-cut"
                            value={cut}
                            checked={form.jerseyCut === cut}
                            onChange={() => {
                              updateField('jerseyCut', cut);
                              updateField('jerseySize', '');
                            }}
                          />
                          <span className="jersey-option-icon"><Icon size={30} strokeWidth={1.8} aria-hidden="true" /></span>
                          <strong>{label}</strong>
                          {form.jerseyCut === cut && <Check size={17} className="jersey-option-check" aria-hidden="true" />}
                        </label>
                        <label className="jersey-size-label" htmlFor={`jersey-size-${cut}`}>Talla {label.toLowerCase()}</label>
                        <select
                          id={`jersey-size-${cut}`}
                          className="jersey-size-select"
                          value={form.jerseyCut === cut ? form.jerseySize : ''}
                          onChange={(event) => updateField('jerseySize', event.target.value as RegistrationInput['jerseySize'])}
                          disabled={form.jerseyCut !== cut}
                          aria-invalid={form.jerseyCut === cut && Boolean(errors.jerseySize)}
                          data-testid={`select-jersey-size-${cut}`}
                        >
                          <option value="">Elige una talla</option>
                          {jerseySizes.map((size) => <option key={size} value={size}>{size}</option>)}
                        </select>
                      </div>
                    ))}
                  </div>
                  {errors.jerseyCut && <span className="field-error" role="alert">{errors.jerseyCut}</span>}
                  {errors.jerseySize && <span className="field-error" role="alert">{errors.jerseySize}</span>}
                </section>
              </>
            )}

            {/* Keep the discount mounted so validation and applied state survive step changes. */}
            <section className="form-section" hidden={step !== 2}>
              <div className="section-heading"><div className="section-icon"><Mail size={18} /></div><div><h3>Una nota para la organización</h3><p>Opcional. Cuéntanos algo que debamos saber.</p></div></div>
              <div className="field full"><label htmlFor="notes">Comentarios</label><textarea id="notes" value={form.notes ?? ''} onChange={(event) => updateField('notes', event.target.value)} placeholder="Alergias, preferencias o cualquier detalle útil…" data-testid="input-notes" /></div>
              <DiscountCodeField appliedCode={form.discountCode} amount={discountAmount} onChange={(code, amount) => {
                updateField('discountCode', code);
                setDiscountAmount(amount);
              }} />
            </section>

            {step === 3 && (
              <section className="form-section">
                <div className="section-heading"><div className="section-icon"><FileCheck2 size={18} /></div><div><h3>{paymentsPaused ? 'Resumen de la vista previa' : 'Todo listo para la salida'}</h3><p>{paymentsPaused ? 'Consulta cómo quedaría tu inscripción. No se enviará ningún dato.' : 'Una última mirada y te llevamos al pago seguro.'}</p></div></div>
                <dl className="review-list">
                  <div className="review-row"><dt>Participante</dt><dd>{form.firstName} {form.lastName}</dd></div>
                  <div className="review-row"><dt>Contacto</dt><dd>{form.email}<br />{form.phone}</dd></div>
                  <div className="review-row"><dt>Licencia</dt><dd>{form.hasCyclingLicense === null ? 'Sin seleccionar' : form.hasCyclingLicense ? paymentsPaused ? 'Licencia de ciclismo · subida de foto desactivada' : 'Licencia de ciclismo · foto adjuntada' : 'Licencia temporal · dos días (+25 €)'}</dd></div>
                  <div className="review-row"><dt>Alojamiento</dt><dd>{accommodationLabel}</dd></div>
                  <div className="review-row"><dt>Seguro</dt><dd>{form.cancellationInsurance ? 'Cancelación' : 'Sin seguro de cancelación'}</dd></div>
                  <div className="review-row"><dt>Maillot</dt><dd>{form.jerseyCut ? `${form.jerseyCut === 'men' ? 'Hombre' : 'Mujer'} · Talla ${form.jerseySize || '—'}` : 'Sin seleccionar'}</dd></div>
                  {form.discountCode && discountAmount > 0 && <div className="review-row"><dt>Descuento</dt><dd>{form.discountCode} · −{formatPrice(discountAmount, currency)} sobre el total</dd></div>}
                </dl>
                <div className="terms-box">
                  <input id="terms" type="checkbox" checked={form.termsAccepted} onChange={(event) => updateField('termsAccepted', event.target.checked)} data-testid="input-terms" />
                  <label htmlFor="terms">He leído y acepto el reglamento de la carrera, las condiciones de inscripción y el tratamiento de mis datos para gestionar mi participación. <a href="#reglamento" data-testid="link-rules">Ver condiciones</a></label>
                </div>
                {errors.termsAccepted && <span className="field-error" role="alert" data-testid="error-terms">{errors.termsAccepted}</span>}
                <div className="terms-box">
                  <input id="marketing" type="checkbox" checked={Boolean(form.marketingAccepted)} onChange={(event) => updateField('marketingAccepted', event.target.checked)} data-testid="input-marketing" />
                  <label htmlFor="marketing">Quiero recibir avisos prácticos y novedades de futuras ediciones. Puedes darte de baja cuando quieras.</label>
                </div>
              </section>
            )}
          </div>

          <div className="action-row">
            {step > 1 ? <button className="button button-quiet" type="button" onClick={() => setStep((current) => current - 1)} disabled={isSubmitting} data-testid="button-previous-step"><ArrowLeft size={16} /> Atrás</button> : <span />}
            {step < 3 ? <button className="button button-primary" type="button" onClick={() => { if (paymentsPaused || validateStep(step)) setStep((current) => current + 1); }} disabled={isUploading} data-testid="button-next-step">Siguiente <ArrowRight size={16} /></button> : <button className="button button-primary" type="button" onClick={submitRegistration} disabled={paymentsPaused || isSubmitting} data-testid="button-submit-registration">{paymentsPaused ? 'Envío y pago desactivados' : isSubmitting ? 'Preparando tu salida…' : registration ? 'Reintentar pago seguro' : 'Pasar al pago seguro'} {isSubmitting ? <RefreshCw className="animate-spin" size={16} /> : <LockKeyhole size={16} />}</button>}
          </div>
        </section>

        <SummaryCard race={race} form={form} discountAmount={discountAmount} />
      </main>
      <footer className="site-footer" id="reglamento">Inscripción Carrera de Bicis · Datos mínimos, decisiones claras y una ruta que merece la pena.</footer>
    </div>
  );
}

function Field({ label, required, error, children }: { label: string; required?: boolean; error?: string; children: ReactNode }) {
  return <div className="field"><label>{label}{required && <span className="required"> *</span>}{children}</label>{error && <span className="field-error" role="alert">{error}</span>}</div>;
}

function ChoiceCard({ name, value, inputType = 'radio', checked, onChange, title, detail, price, testId }: { name: string; value: string; inputType?: 'radio' | 'checkbox'; checked: boolean; onChange: () => void; title: string; detail: string; price: string; testId: string }) {
  return <label className={`choice-card ${checked ? 'is-selected' : ''}`} data-testid={testId}><input type={inputType} name={name} value={value} checked={checked} onChange={onChange} /><span className="choice-title">{title}</span><span className="choice-detail">{detail}</span><span className="choice-price">{price}</span>{checked && <Check size={15} style={{ position: 'absolute', top: '0.8rem', right: '0.8rem', color: 'hsl(var(--race-coral))' }} />}</label>;
}

function ToggleRow({ icon, title, detail, checked, onChange, price, testId }: { icon: ReactNode; title: string; detail: string; checked: boolean; onChange: (checked: boolean) => void; price: string; testId: string }) {
  return <div className="toggle-row" data-testid={`${testId}-row`}><div className="toggle-copy">{icon}<div><strong>{title}</strong><span>{detail}</span></div></div><div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}><span className="choice-price" style={{ padding: 0 }}>{price}</span><label className="switch"><input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} data-testid={testId} /><span className="switch-track" /></label></div></div>;
}

function Home() {
  const returnState = useMemo(() => getReturnState(), []);
  const [showReturnState, setShowReturnState] = useState<ReturnState>(returnState);
  const raceQuery = useGetRace({ query: { queryKey: getGetRaceQueryKey(), staleTime: 300000 } });

  const returnToRegistration = () => {
    window.history.replaceState({}, '', window.location.pathname);
    setShowReturnState(null);
  };

  if (showReturnState) return <PendingState state={showReturnState} onReturn={returnToRegistration} />;
  if (raceQuery.isLoading) return <LoadingState />;
  if (raceQuery.isError || !raceQuery.data) return <RaceUnavailable onRetry={() => raceQuery.refetch()} />;
  return <RegistrationFlow race={raceQuery.data} />;
}

function SignInPage() {
  const backofficeReturn = new URLSearchParams(window.location.search).get('return_to') === 'backoffice';
  const destination = `${basePath}${backofficeReturn ? '/backoffice' : '/'}`;
  return <main className="auth-page"><div className="auth-intro"><a href={`${basePath}/`}>{backofficeReturn ? '← Tornar a la inscripció' : '← Volver a la inscripción'}</a><span className="eyebrow">Specilized Cadí Challenge</span><h1>{backofficeReturn ? 'Accés de l’organització.' : 'Protege tu licencia.'}</h1><p>{backofficeReturn ? 'Identifica’t amb el compte autoritzat per consultar el registre privat.' : 'Inicia sesión para adjuntar una foto de tu licencia de ciclismo. Al terminar, volverás al formulario con tus datos guardados.'}</p></div><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up${backofficeReturn ? '?return_to=backoffice' : ''}`} fallbackRedirectUrl={destination} {...(backofficeReturn ? { forceRedirectUrl: destination } : {})} /></main>;
}

function SignUpPage() {
  const backofficeReturn = new URLSearchParams(window.location.search).get('return_to') === 'backoffice';
  const destination = `${basePath}${backofficeReturn ? '/backoffice' : '/'}`;
  return <main className="auth-page"><div className="auth-intro"><a href={`${basePath}/`}>{backofficeReturn ? '← Tornar a la inscripció' : '← Volver a la inscripción'}</a><span className="eyebrow">Specilized Cadí Challenge</span><h1>{backofficeReturn ? 'Crea l’accés.' : 'Crea tu acceso.'}</h1><p>{backofficeReturn ? 'El compte d’organització necessita autorització per veure el registre privat.' : 'Tu cuenta permite guardar la foto de tu licencia de forma privada. Después podrás terminar la inscripción.'}</p></div><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in${backofficeReturn ? '?return_to=backoffice' : ''}`} fallbackRedirectUrl={destination} {...(backofficeReturn ? { forceRedirectUrl: destination } : {})} /></main>;
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/organizacion" component={OrganizerPage} />
        <Route path="/sign-in/*?" component={SignInPage} />
        <Route path="/sign-up/*?" component={SignUpPage} />
        <Route path="/backoffice" component={BackofficePage} />
        <Route component={NotFoundState} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

const clerkAppearance = {
  theme: 'simple' as const,
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/brc-cadi-logo.png`,
  },
  variables: {
    colorPrimary: '#db6446',
    colorForeground: '#1c3340',
    colorMutedForeground: '#52636b',
    colorDanger: '#af302c',
    colorBackground: '#f7f4ed',
    colorInput: '#ffffff',
    colorInputForeground: '#1c3340',
    colorNeutral: '#cad1cc',
    fontFamily: 'Manrope, sans-serif',
    borderRadius: '0.65rem',
  },
  elements: {
    cardBox: { width: '440px', maxWidth: '100%', backgroundColor: '#f7f4ed' },
    logoImage: { height: '90px', width: 'auto', objectFit: 'contain' as const },
    headerTitle: { color: '#1c3340' },
    headerSubtitle: { color: '#52636b' },
    socialButtonsBlockButton: { backgroundColor: '#ffffff', color: '#1c3340', borderColor: '#cad1cc' },
    socialButtonsBlockButtonText: { color: '#1c3340' },
    formFieldLabel: { color: '#1c3340' },
    footerActionText: { color: '#52636b' },
    footerActionLink: { color: '#b84c35' },
  },
};

function ClerkRoutes() {
  const [, setLocation] = useLocation();
  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        ...esES,
        signIn: { ...esES.signIn, start: { ...esES.signIn?.start, title: 'Entra en tu cuenta', subtitle: 'Adjunta tu licencia de ciclismo de forma privada.' } },
        signUp: { ...esES.signUp, start: { ...esES.signUp?.start, title: 'Crea tu cuenta', subtitle: 'Guarda tu licencia de ciclismo de forma privada.' } },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <Router />
    </ClerkProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={basePath}>
          <ClerkRoutes />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
