import { useEffect, useRef, useState } from 'react';
import { useValidateDiscountCode } from '@workspace/api-client-react';

type Props = {
  appliedCode?: string;
  amount: number;
  onChange: (code: string | undefined, amount: number) => void;
};

export default function DiscountCodeField({ appliedCode, amount, onChange }: Props) {
  const [input, setInput] = useState(appliedCode ?? '');
  const [error, setError] = useState('');
  const initialCode = useRef(appliedCode);
  const validation = useValidateDiscountCode();

  const apply = (code: string) => {
    if (validation.isPending) return;
    setError('');
    if (!code.trim()) {
      setError('Introduce un código de descuento.');
      return;
    }
    validation.mutate({ data: { code: code.trim() } }, {
      onSuccess: (discount) => {
        setInput(discount.code);
        onChange(discount.code, discount.amount);
      },
      onError: (failure) => {
        onChange(undefined, 0);
        setError((failure as { status?: number }).status === 400
          ? 'El código de descuento no es válido.'
          : 'No se ha podido comprobar el código. Inténtalo de nuevo.');
      },
    });
  };

  useEffect(() => {
    // Revalidate restored drafts; a saved code or amount is never trusted.
    if (initialCode.current) apply(initialCode.current);
  }, []);

  return (
    <div className="field full discount-code-field">
      <label htmlFor="discount-code">Código de descuento</label>
      <div className="discount-code-controls">
        <input id="discount-code" value={input} maxLength={40} autoComplete="off"
          placeholder="Introduce tu código" disabled={validation.isPending}
          aria-invalid={Boolean(error)} aria-describedby="discount-code-status"
          data-testid="input-discount-code"
          onChange={(event) => {
            setInput(event.target.value);
            setError('');
            if (appliedCode) onChange(undefined, 0);
          }}
          onKeyDown={(event) => {
            if (event.key === 'Enter') { event.preventDefault(); apply(input); }
          }} />
        <button className="button button-primary" type="button" disabled={validation.isPending || !input.trim()}
          data-testid="button-apply-discount" onClick={() => apply(input)}>
          {validation.isPending ? 'Comprobando…' : 'Aplicar'}
        </button>
      </div>
      <div id="discount-code-status">
        {error && <p className="field-error" role="alert" data-testid="error-discount-code">{error}</p>}
        {validation.isPending && <p role="status">Comprobando el código…</p>}
        {!validation.isPending && appliedCode && amount > 0 && (
          <div className="discount-code-applied">
            <p role="status" data-testid="text-discount-applied">{appliedCode}: −{new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' }).format(amount)} sobre el total.</p>
            <button className="button button-quiet" type="button" data-testid="button-remove-discount" onClick={() => {
              setInput(''); setError(''); onChange(undefined, 0);
            }}>Quitar descuento</button>
          </div>
        )}
      </div>
    </div>
  );
}
