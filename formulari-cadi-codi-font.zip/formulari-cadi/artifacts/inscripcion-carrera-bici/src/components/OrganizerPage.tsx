import { useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { useAuth } from '@clerk/react';
import { useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, Bike, Check, CircleAlert, Eye, EyeOff, FileImage, LockKeyhole, RefreshCw, ShieldCheck, UserRoundPlus, UsersRound } from 'lucide-react';
import {
  getGetOrganizerAccessQueryKey,
  getListOrganizerMembersQueryKey,
  getListOrganizerRegistrationsQueryKey,
  useGetOrganizerAccess,
  useListOrganizerRegistrations,
  useListOrganizerMembers,
  useSaveOrganizerMember,
  useRemoveOrganizerMember,
  type LicenseReview,
  type OrganizerMember,
} from '@workspace/api-client-react';

const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
type Role = OrganizerMember['role'];

function errorStatus(error: unknown): number | undefined {
  if (!error || typeof error !== 'object') return undefined;
  const candidate = error as { status?: number; response?: { status?: number } };
  return candidate.status ?? candidate.response?.status;
}

function errorMessage(error: unknown, fallback: string) {
  const status = errorStatus(error);
  if (status === 401) return 'Tu sesión ha caducado. Inicia sesión de nuevo para continuar.';
  if (status === 403) return 'Tu cuenta no tiene permiso para realizar esta acción.';
  return fallback;
}

function dateLabel(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? 'Fecha no disponible'
    : new Intl.DateTimeFormat('es-ES', { day: '2-digit', month: 'short', year: 'numeric' }).format(date);
}

function statusLabel(value: string) {
  return ({ pending: 'Pendiente', paid: 'Pagada', cancelled: 'Cancelada' } as Record<string, string>)[value] ?? value;
}

function PanelState({ icon, title, description, action }: {
  icon: ReactNode; title: string; description: string; action?: ReactNode;
}) {
  return <div className="org-state"><div className="org-state-icon">{icon}</div><h3>{title}</h3><p>{description}</p>{action}</div>;
}

function SkeletonRows() {
  return <div role="status" aria-label="Cargando datos"><div className="org-skeleton" /><div className="org-skeleton" /><div className="org-skeleton" /><span className="sr-only">Cargando datos del equipo</span></div>;
}

function ReviewRow({ review }: { review: LicenseReview }) {
  const [isOpen, setIsOpen] = useState(false);
  const [photoState, setPhotoState] = useState<'loading' | 'loaded' | 'error'>('loading');
  const [attempt, setAttempt] = useState(0);
  const photoUrl = `/api/organization/registrations/${encodeURIComponent(review.id)}/license`;
  const retry = () => { setPhotoState('loading'); setAttempt((current) => current + 1); };

  return <div data-testid={`row-review-${review.id}`}>
    <div className="org-row">
      <div className="org-person"><strong data-testid={`text-rider-${review.id}`}>{review.firstName} {review.lastName}</strong><small>REF. {review.id}</small></div>
      <span className="org-date" data-testid={`text-date-${review.id}`}>{dateLabel(review.createdAt)}</span>
      <span className="org-status" data-status={review.status} data-testid={`status-registration-${review.id}`}>{statusLabel(review.status)}</span>
      <button className="org-action" type="button" aria-expanded={isOpen} onClick={() => { setIsOpen((open) => !open); setPhotoState('loading'); }} data-testid={`button-photo-${review.id}`}>
        {isOpen ? <EyeOff size={15} /> : <Eye size={15} />}{isOpen ? 'Cerrar foto' : 'Ver licencia'}
      </button>
    </div>
    {isOpen && <div className="org-photo" data-testid={`panel-photo-${review.id}`}>
      <div className="org-photo-frame">
        {photoState === 'error'
          ? <PanelState icon={<CircleAlert size={22} />} title="No se pudo abrir la foto" description="Comprueba tu acceso o la conexión y vuelve a intentarlo." action={<button className="org-action" type="button" onClick={retry} data-testid={`button-retry-photo-${review.id}`}><RefreshCw size={14} /> Reintentar</button>} />
          : <>
            {photoState === 'loading' && <span role="status">Abriendo foto privada…</span>}
            <img key={`${review.id}-${attempt}`} src={attempt ? `${photoUrl}?retry=${attempt}` : photoUrl} alt={`Licencia de ${review.firstName} ${review.lastName}`} style={{ display: photoState === 'loaded' ? 'block' : 'none' }} onLoad={() => setPhotoState('loaded')} onError={() => setPhotoState('error')} referrerPolicy="same-origin" data-testid={`image-license-${review.id}`} />
          </>}
      </div>
      <p className="org-photo-note"><LockKeyhole size={14} /> Documento privado. Solo visible para el equipo autorizado.</p>
    </div>}
  </div>;
}

function MemberRow({ member, busy, onSave, onRemove }: {
  member: OrganizerMember;
  busy: boolean;
  onSave: (member: OrganizerMember) => void;
  onRemove: (id: string) => void;
}) {
  const [role, setRole] = useState<Role>(member.role);
  const [confirming, setConfirming] = useState(false);
  useEffect(() => { setRole(member.role); }, [member.role]);

  return <div className="org-member-row" data-testid={`row-member-${member.userId}`}>
    <div className="org-person"><strong data-testid={`text-member-${member.userId}`}>{member.userId}</strong><small>Acceso delegado</small></div>
    <div className="org-member-controls">
      {confirming ? <>
        <span className="org-date">¿Revocar acceso?</span>
        <button className="org-action danger" type="button" disabled={busy} onClick={() => { onRemove(member.userId); setConfirming(false); }} data-testid={`button-confirm-revoke-${member.userId}`}>Sí, revocar</button>
        <button className="org-action" type="button" disabled={busy} onClick={() => setConfirming(false)} data-testid={`button-cancel-revoke-${member.userId}`}>Cancelar</button>
      </> : <>
        <select className="org-field" value={role} onChange={(event) => setRole(event.target.value as Role)} aria-label={`Rol de ${member.userId}`} disabled={busy} data-testid={`select-role-${member.userId}`}><option value="reviewer">Revisor</option><option value="admin">Administrador</option></select>
        <button className="org-action" type="button" disabled={busy || role === member.role} onClick={() => onSave({ userId: member.userId, role })} data-testid={`button-save-role-${member.userId}`}>Guardar</button>
        <button className="org-action danger" type="button" disabled={busy} onClick={() => setConfirming(true)} data-testid={`button-revoke-${member.userId}`}>Revocar</button>
      </>}
    </div>
  </div>;
}

function OrganizerWorkspace({ userId }: { userId: string }) {
  const queryClient = useQueryClient();
  const access = useGetOrganizerAccess({ query: { enabled: true, queryKey: getGetOrganizerAccessQueryKey(), retry: false } });
  const authorized = access.data?.role === 'admin' || access.data?.role === 'reviewer';
  const isAdmin = access.data?.role === 'admin';
  const registrations = useListOrganizerRegistrations({ query: { enabled: authorized, queryKey: getListOrganizerRegistrationsQueryKey(), retry: false } });
  const members = useListOrganizerMembers({ query: { enabled: isAdmin, queryKey: getListOrganizerMembersQueryKey(), retry: false } });
  const saveMember = useSaveOrganizerMember();
  const removeMember = useRemoveOrganizerMember();
  const [newId, setNewId] = useState('');
  const [newRole, setNewRole] = useState<Role>('reviewer');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const busy = saveMember.isPending || removeMember.isPending;

  const refreshTeam = () => {
    void queryClient.invalidateQueries({ queryKey: getListOrganizerMembersQueryKey() });
    void queryClient.invalidateQueries({ queryKey: getGetOrganizerAccessQueryKey() });
  };
  const save = (member: OrganizerMember, reset = false) => {
    setFeedback(null);
    saveMember.mutate({ data: member }, {
      onSuccess: (saved) => {
        setFeedback({ type: 'success', text: `Acceso ${saved.role === 'admin' ? 'de administrador' : 'de revisor'} guardado para ${saved.userId}.` });
        if (reset) { setNewId(''); setNewRole('reviewer'); }
        refreshTeam();
      },
      onError: (error) => setFeedback({ type: 'error', text: errorMessage(error, 'No se ha podido guardar el acceso. Inténtalo de nuevo.') }),
    });
  };
  const remove = (id: string) => {
    setFeedback(null);
    removeMember.mutate({ userId: id }, {
      onSuccess: () => { setFeedback({ type: 'success', text: `Acceso revocado para ${id}.` }); refreshTeam(); },
      onError: (error) => setFeedback({ type: 'error', text: errorMessage(error, 'No se ha podido revocar el acceso. Inténtalo de nuevo.') }),
    });
  };
  const addMember = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const id = newId.trim();
    if (!id) { setFeedback({ type: 'error', text: 'Introduce el ID de usuario antes de guardar.' }); return; }
    save({ userId: id, role: newRole }, true);
  };

  return <>
    {access.isPending ? <div className="org-panel"><SkeletonRows /></div>
      : access.isError ? <div className="org-panel"><PanelState icon={<CircleAlert size={22} />} title={errorStatus(access.error) === 403 ? 'Acceso restringido' : 'No se pudo comprobar tu acceso'} description={errorMessage(access.error, 'No hemos podido verificar tus permisos. Vuelve a intentarlo.')} action={errorStatus(access.error) === 401 ? <a className="org-action primary" href={`${basePath}/sign-in`} data-testid="link-organizer-relogin">Iniciar sesión</a> : <button className="org-action" type="button" onClick={() => void access.refetch()} data-testid="button-retry-access"><RefreshCw size={14} /> Reintentar</button>} />{errorStatus(access.error) === 403 && <div className="org-state"><p>Comparte este ID con la persona administradora:</p><code data-testid="text-organizer-denied-id">{userId}</code></div>}</div>
        : !authorized ? <div className="org-panel"><div className="org-state"><div className="org-state-icon"><LockKeyhole size={22} /></div><h2>Tu cuenta aún no tiene acceso.</h2><p>Comparte este ID con la persona administradora para que te añada al equipo de revisión.</p><code data-testid="text-organizer-user-id">{access.data?.userId ?? userId}</code></div></div>
          : <>
            <section className="org-section" aria-labelledby="org-reviews-heading">
              <div className="org-section-head"><div><span className="eyebrow">01 / Documentación</span><h2 id="org-reviews-heading">Licencias adjuntadas</h2><p>Abre una foto solo cuando necesites consultarla. El estado corresponde a la inscripción, no a la verificación de la licencia.</p></div><span className="org-number" data-testid="text-review-count">{registrations.data?.length ?? '—'}</span></div>
              <div className="org-panel">
                <div className="org-table-labels"><span>Participante / referencia</span><span>Fecha de registro</span><span>Estado</span><span>Documento</span></div>
                {registrations.isPending ? <SkeletonRows /> : registrations.isError ? <PanelState icon={<CircleAlert size={22} />} title="No se pudo cargar la lista" description={errorMessage(registrations.error, 'Las inscripciones no están disponibles ahora mismo.')} action={<button className="org-action" type="button" onClick={() => void registrations.refetch()} data-testid="button-retry-registrations"><RefreshCw size={14} /> Reintentar</button>} />
                  : registrations.data?.length ? registrations.data.map((review) => <ReviewRow key={review.id} review={review} />)
                    : <PanelState icon={<FileImage size={22} />} title="Sin licencias por revisar" description="Cuando se adjunten licencias a inscripciones, aparecerán aquí con su fecha y estado." />}
              </div>
            </section>
            {isAdmin && <section className="org-section" aria-labelledby="org-team-heading">
              <div className="org-section-head"><div><span className="eyebrow">02 / Accesos</span><h2 id="org-team-heading">Equipo organizador</h2><p>Concede permisos por ID de usuario. Los revisores consultan licencias; los administradores gestionan también el equipo.</p></div><UsersRound size={23} aria-hidden="true" /></div>
              {feedback && <div className={`org-feedback ${feedback.type === 'error' ? 'error' : ''}`} role={feedback.type === 'error' ? 'alert' : 'status'} data-testid="status-member-feedback">{feedback.type === 'error' ? <CircleAlert size={16} /> : <Check size={16} />}{feedback.text}</div>}
              <div className="org-panel">
                <form className="org-member-form" onSubmit={addMember}>
                  <div className="org-field-wrap"><label htmlFor="org-new-id">ID de usuario</label><input className="org-field" id="org-new-id" value={newId} onChange={(event) => setNewId(event.target.value)} placeholder="user_..." autoComplete="off" required data-testid="input-member-id" /></div>
                  <div className="org-field-wrap role"><label htmlFor="org-new-role">Rol</label><select className="org-field" id="org-new-role" value={newRole} onChange={(event) => setNewRole(event.target.value as Role)} data-testid="select-member-role"><option value="reviewer">Revisor</option><option value="admin">Administrador</option></select></div>
                  <button className="org-action primary" type="submit" disabled={busy} data-testid="button-add-member"><UserRoundPlus size={15} /> {saveMember.isPending ? 'Guardando…' : 'Guardar acceso'}</button>
                </form>
                {members.isPending ? <SkeletonRows /> : members.isError ? <PanelState icon={<CircleAlert size={22} />} title="No se pudo cargar el equipo" description={errorMessage(members.error, 'Los miembros no están disponibles ahora mismo.')} action={<button className="org-action" type="button" onClick={() => void members.refetch()} data-testid="button-retry-members"><RefreshCw size={14} /> Reintentar</button>} />
                  : members.data?.length ? members.data.map((member) => <MemberRow key={member.userId} member={member} busy={busy} onSave={save} onRemove={remove} />)
                    : <PanelState icon={<UsersRound size={22} />} title="Aún no hay miembros delegados" description="Añade el ID de una persona del equipo para conceder acceso a este espacio." />}
              </div>
            </section>}
          </>}
  </>;
}

export default function OrganizerPage() {
  const { isLoaded, isSignedIn, userId } = useAuth();
  const queryClient = useQueryClient();
  const identity = isLoaded ? (isSignedIn ? userId ?? null : null) : undefined;
  const previousIdentity = useRef<string | null | undefined>(undefined);
  const [readyIdentity, setReadyIdentity] = useState<string | null>(null);

  useEffect(() => {
    if (identity === undefined) return;
    if (previousIdentity.current !== identity) {
      queryClient.clear();
      previousIdentity.current = identity;
      setReadyIdentity(identity);
    }
  }, [identity, queryClient]);
  useEffect(() => { document.title = 'Organización · Inscripción Carrera de Bicis'; }, []);

  return <div className="org-app noise">
    <header className="org-topbar"><div className="org-topbar-inner">
      <a className="brand-lockup" href={`${basePath}/`} data-testid="link-organizer-brand"><span className="brand-mark"><Bike size={21} strokeWidth={2.2} /></span><span><span className="brand-name">Inscripción Carrera</span><span className="brand-caption">de bicis · área privada</span></span></a>
      <a className="org-back" href={`${basePath}/`} data-testid="link-organizer-home"><ArrowLeft size={15} /> Volver a inscripción</a>
    </div></header>
    <div className="org-masthead"><div className="org-masthead-inner"><div><span className="org-kicker"><ShieldCheck size={15} /> Control de carrera / acceso privado</span><h1>Área de <em>organización.</em></h1><p>Un lugar para revisar la documentación de los participantes y coordinar los accesos del equipo. Las fotos permanecen privadas hasta que decides abrirlas.</p></div>{readyIdentity && isSignedIn && <div className="org-identity"><span>Sesión actual</span><strong data-testid="text-organizer-session-id">{readyIdentity}</strong></div>}</div></div>
    <main className="org-body">
      {!isLoaded || (isSignedIn && readyIdentity !== userId) ? <div className="org-panel"><SkeletonRows /></div>
        : !isSignedIn ? <div className="org-panel"><PanelState icon={<LockKeyhole size={22} />} title="Entra con tu cuenta para continuar" description="Este espacio es solo para el equipo organizador. Inicia sesión y vuelve aquí para consultar tus permisos." action={<a className="org-action primary" href={`${basePath}/sign-in`} data-testid="link-organizer-sign-in">Iniciar sesión</a>} /></div>
          : <OrganizerWorkspace key={userId ?? ''} userId={userId ?? ''} />}
    </main>
  </div>;
}