import type { BackofficeRegistration } from '@workspace/api-client-react';
import { exportValue, type Column } from './backoffice-columns';

export async function createParticipantsWorkbook(rows: BackofficeRegistration[], selectedColumns: Column[]) {
  const { default: ExcelJS } = await import('exceljs');
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Cadí Challenge';
  workbook.created = new Date();
  const sheet = workbook.addWorksheet('Participants', { views: [{ state: 'frozen', ySplit: 1 }] });
  sheet.columns = [
    ...selectedColumns.map(c => ({ header: c.label, key: c.key, width: c.key === 'orderNumber' ? 18 : c.key === 'email' ? 36 : 24 })),
    { header: 'Desglossament dels imports', key: 'breakdownVerification', width: 28 },
  ];
  for (const row of rows) {
    const values = Object.fromEntries(selectedColumns.map(c => [c.key, exportValue(row, c.key)]));
    sheet.addRow({ ...values, breakdownVerification: row.breakdownVerified ? 'Verificat' : 'Estimat / no verificat' });
  }
  selectedColumns.forEach((column, index) => {
    sheet.getColumn(index + 1).numFmt = column.numeric ? '#,##0.00 "€"' : '@';
  });
  sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF203940' } };
  sheet.autoFilter = { from: { row: 1, column: 1 }, to: { row: Math.max(1, rows.length + 1), column: sheet.columnCount } };
  return workbook;
}

export async function downloadParticipants(rows: BackofficeRegistration[], selectedColumns: Column[]) {
  const workbook = await createParticipantsWorkbook(rows, selectedColumns);
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([new Uint8Array(buffer)], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `participants-cadi-${new Date().toISOString().slice(0, 10)}.xlsx`;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
}