import { columns, type ColumnKey } from './backoffice-columns';

export type ColumnPreferences = { order: ColumnKey[]; hidden: ColumnKey[] };
export const defaultPreferences = (): ColumnPreferences => ({ order: columns.map(c => c.key), hidden: [] });
export function normalizePreferences(input: unknown): ColumnPreferences {
  const defaults = defaultPreferences();
  if (!input || typeof input !== 'object') return defaults;
  const candidate = input as { order?: unknown; hidden?: unknown };
  const validKey = (key: unknown): key is ColumnKey => typeof key === 'string' && defaults.order.includes(key as ColumnKey);
  const order = Array.isArray(candidate.order) ? [...new Set(candidate.order.filter(validKey))] : [];
  defaults.order.forEach(key => { if (!order.includes(key)) order.push(key); });
  const hidden = Array.isArray(candidate.hidden) ? [...new Set(candidate.hidden.filter(validKey))] : [];
  return { order, hidden: hidden.length === order.length ? hidden.slice(1) : hidden };
}
export function moveColumn(prefs: ColumnPreferences, key: ColumnKey, target: number): ColumnPreferences {
  const order = prefs.order.filter(item => item !== key);
  order.splice(Math.max(0, Math.min(target, order.length)), 0, key);
  return { ...prefs, order };
}