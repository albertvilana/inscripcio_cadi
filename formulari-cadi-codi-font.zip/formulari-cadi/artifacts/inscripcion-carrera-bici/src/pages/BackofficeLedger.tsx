import { useMemo, useState } from 'react';
import { ArrowDown, ArrowDownUp, ArrowUp, Download, GripVertical, Settings2 } from 'lucide-react';
import type { BackofficeRegistration } from '@workspace/api-client-react';
import { cellContent, collator, columns, compareRows, type ColumnKey } from './backoffice-columns';
import { defaultPreferences, moveColumn, normalizePreferences, type ColumnPreferences } from './backoffice-column-preferences';
import { downloadParticipants } from './backoffice-excel';

export default function BackofficeLedger({ registrations, userId }: { registrations: BackofficeRegistration[]; userId: string }) {
  const storageKey = `cadi-backoffice-columns-v1:${userId}`;
  const [preferences, setPreferences] = useState<ColumnPreferences>(() => {
    try { return normalizePreferences(JSON.parse(localStorage.getItem(storageKey) ?? 'null')); }
    catch { return defaultPreferences(); }
  });
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [dragged, setDragged] = useState<ColumnKey | null>(null);
  const [notice, setNotice] = useState('');
  const [exporting, setExporting] = useState(false);
  const [sort, setSort] = useState<{ key: ColumnKey; direction: 'asc' | 'desc' }>({ key: 'createdAt', direction: 'desc' });
  const orderedColumns = preferences.order.map(key => columns.find(column => column.key === key)!);
  const visibleColumns = orderedColumns.filter(column => !preferences.hidden.includes(column.key));
  const sorted = useMemo(() => [...registrations].sort((a, b) => {
    const result = compareRows(a, b, sort.key);
    return (sort.direction === 'asc' ? result : -result) || collator.compare(a.orderNumber, b.orderNumber);
  }), [registrations, sort]);
  const update = (next: ColumnPreferences) => {
    setPreferences(next);
    try { localStorage.setItem(storageKey, JSON.stringify(next)); setNotice(''); }
    catch { setNotice('No s’ha pogut desar la configuració en aquest navegador. Els canvis es mantindran mentre aquesta pàgina estigui oberta.'); }
  };
  const exportExcel = async (all: boolean) => {
    setExporting(true);
    setNotice('');
    try { await downloadParticipants(sorted, all ? orderedColumns : visibleColumns); }
    catch { setNotice('No s’ha pogut generar el fitxer Excel. Torna-ho a provar.'); }
    finally { setExporting(false); }
  };
  return (
    <>
      <div className="bo-table-tools">
        <button className="bo-refresh" type="button" aria-expanded={settingsOpen} aria-controls="bo-column-settings" onClick={() => setSettingsOpen(value => !value)} data-testid="button-manage-columns"><Settings2 /> Columnes ({visibleColumns.length}/{columns.length})</button>
        <button className="bo-refresh" type="button" disabled={exporting} onClick={() => { void exportExcel(false); }} data-testid="button-export-excel"><Download /> {exporting ? 'Generant Excel…' : 'Excel · columnes visibles'}</button>
        <button className="bo-refresh" type="button" disabled={exporting} onClick={() => { void exportExcel(true); }} data-testid="button-export-excel-all"><Download /> Excel · totes les dades</button>
      </div>
      {notice && <p className="bo-notice" role="alert">{notice}</p>}
      {settingsOpen && (
        <section className="bo-column-settings" id="bo-column-settings" aria-label="Configura les columnes">
          <div className="bo-column-heading"><div><strong>Ordre i visibilitat de les columnes</strong><p>Arrossega les files o utilitza les fletxes. Desmarca una columna per ocultar-la. Es desa per al teu compte en aquest navegador.</p></div><button className="bo-refresh" type="button" onClick={() => update(defaultPreferences())} data-testid="button-reset-columns">Restableix</button></div>
          <ol className="bo-column-list">
            {orderedColumns.map((column, index) => (
              <li key={column.key} draggable onDragStart={event => { setDragged(column.key); event.dataTransfer.setData('text/plain', column.key); }} onDragEnd={() => setDragged(null)} onDragOver={event => event.preventDefault()} onDrop={event => { event.preventDefault(); if (dragged) update(moveColumn(preferences, dragged, index)); setDragged(null); }} data-testid={`column-setting-${column.key}`}>
                <GripVertical size={16} aria-hidden="true" />
                <label><input type="checkbox" checked={!preferences.hidden.includes(column.key)} disabled={visibleColumns.length === 1 && !preferences.hidden.includes(column.key)} onChange={event => update({ ...preferences, hidden: event.target.checked ? preferences.hidden.filter(key => key !== column.key) : [...preferences.hidden, column.key] })} data-testid={`checkbox-column-${column.key}`} /> {column.label}</label>
                <button type="button" aria-label={`Mou ${column.label} amunt`} disabled={index === 0} onClick={() => update(moveColumn(preferences, column.key, index - 1))} data-testid={`button-column-up-${column.key}`}><ArrowUp size={15} /></button>
                <button type="button" aria-label={`Mou ${column.label} avall`} disabled={index === orderedColumns.length - 1} onClick={() => update(moveColumn(preferences, column.key, index + 1))} data-testid={`button-column-down-${column.key}`}><ArrowDown size={15} /></button>
              </li>
            ))}
          </ol>
        </section>
      )}
      <p className="bo-export-note">L’Excel inclou tots els participants en l’ordre actual del llistat, amb imports numèrics en euros i indicació dels desglossaments estimats.</p>
      <div className="bo-table-wrap" role="region" aria-label="Registre d’inscripcions; desplaça’t horitzontalment per veure totes les columnes" tabIndex={0}>
        <table className="bo-table" data-testid="table-registrations">
          <thead><tr>{visibleColumns.map(column => {
            const active = sort.key === column.key;
            return <th key={column.key} scope="col" className={[column.numeric ? 'bo-number' : '', column.key === 'orderNumber' ? 'bo-order-heading' : ''].join(' ')} aria-sort={active ? sort.direction === 'asc' ? 'ascending' : 'descending' : 'none'}>
              <button type="button" onClick={() => setSort(current => ({ key: column.key, direction: current.key === column.key && current.direction === 'asc' ? 'desc' : 'asc' }))} data-testid={`button-sort-${column.key}`} aria-label={`Ordena per ${column.label}`}>
                {column.label}{active ? sort.direction === 'asc' ? <ArrowUp className="bo-sort-icon" size={13} /> : <ArrowDown className="bo-sort-icon" size={13} /> : <ArrowDownUp className="bo-sort-icon" size={13} />}
              </button>
            </th>;
          })}</tr></thead>
          <tbody>{sorted.map(row => <tr key={row.orderNumber} data-testid={`row-registration-${row.orderNumber}`}>
            {visibleColumns.map(column => <td key={column.key} className={[column.numeric ? 'bo-num' : '', column.key === 'orderNumber' ? 'bo-order' : '', column.key === 'firstName' || column.key === 'lastName' ? 'bo-person' : '', column.key === 'paidTotalCents' ? 'bo-pay' : '', column.numeric && row[column.key] === 0 ? 'bo-muted-cell' : ''].filter(Boolean).join(' ')} data-testid={`text-${column.key}-${row.orderNumber}`}>{cellContent(row, column.key)}</td>)}
          </tr>)}</tbody>
        </table>
      </div>
    </>
  );
}