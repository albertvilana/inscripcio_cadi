import { useEffect } from 'react';
import { useAuth } from '@clerk/react';
import {
  ArrowLeft, ArrowRight,
  CircleAlert, LockKeyhole, RefreshCw, ShieldCheck,
} from 'lucide-react';
import {
  getGetBackofficeReportQueryKey,
  useGetBackofficeReport,
  type BackofficeSummary,
} from '@workspace/api-client-react';
import BackofficeLedger from './BackofficeLedger';
import { dateLabel, money } from './backoffice-columns';
import './backoffice.css';

function statusCode(error: unknown): number | undefined {
  if (!error || typeof error !== 'object') return undefined;
  const candidate = error as { status?: number; response?: { status?: number } };
  return candidate.status ?? candidate.response?.status;
}

function PageFrame({ children }: { children: React.ReactNode }) {
  return (
    <div className="bo-page">
      <header className="bo-header">
        <div className="bo-identity">
          <img className="bo-logo" src={`${import.meta.env.BASE_URL.replace(/\/$/, '')}/brc-cadi-logo.png`} alt="Specialized Back Road Cadí" />
          <span className="bo-identity-text">
            <strong>Cadí Challenge</strong>
            <small>Organització · 2027</small>
          </span>
        </div>
        <div className="bo-header-right">
          <span className="bo-private"><ShieldCheck size={15} aria-hidden="true" /> Àrea privada</span>
          <a className="bo-back" href={`${import.meta.env.BASE_URL.replace(/\/$/, '')}/`} data-testid="link-back-registration">
            <ArrowLeft size={14} aria-hidden="true" /> Inscripció pública
          </a>
        </div>
      </header>
      {children}
    </div>
  );
}

function AccessState({ kind, onRetry }: { kind: 'loading' | 'signed-out' | 'restricted' | 'error'; onRetry?: () => void }) {
  const content = {
    'signed-out': {
      eyebrow: 'Accés reservat · 01',
      title: 'Inicia sessió per consultar el registre.',
      description: 'Aquest llistat conté dades personals i pagaments dels participants. Inicia sessió amb el teu compte de l’organització per continuar.',
    },
    restricted: {
      eyebrow: 'Accés restringit · 403',
      title: 'Aquest compte no hi té accés.',
      description: 'El registre està reservat a l’equip organitzador. Si hi hauries de tenir accés, demana permisos a la persona responsable de la cursa.',
    },
    error: {
      eyebrow: 'Connexió interrompuda',
      title: 'No podem obrir el registre.',
      description: 'No s’han pogut recuperar les dades. Comprova la connexió i torna-ho a provar; no mostrarem informació sense verificar-la.',
    },
  };
  return (
    <PageFrame>
      <main className="bo-state-shell" aria-live="polite">
        <section className="bo-state" data-testid={`state-backoffice-${kind}`}>
          {kind === 'loading' ? (
            <>
              <span className="bo-overline">Verificant l’accés</span>
              <div className="bo-skeleton wide" style={{ marginTop: 26 }} />
              <div className="bo-skeleton mid" />
              <div className="bo-skeleton short" />
              <p className="sr-only">Carregant el registre privat</p>
            </>
          ) : (
            <>
              <div className="bo-state-icon">{kind === 'error' ? <CircleAlert size={21} /> : <LockKeyhole size={21} />}</div>
              <span className="bo-overline" style={{ display: 'block', marginTop: 26, color: '#a95b45' }}>{content[kind].eyebrow}</span>
              <h1>{content[kind].title}</h1>
              <p>{content[kind].description}</p>
              {kind === 'signed-out' && (
                <a className="bo-action" href={`${import.meta.env.BASE_URL.replace(/\/$/, '')}/sign-in?return_to=backoffice`} data-testid="link-backoffice-sign-in">
                  Inicia sessió <ArrowRight size={15} aria-hidden="true" />
                </a>
              )}
              {kind === 'error' && <button type="button" className="bo-action" onClick={onRetry} data-testid="button-retry-backoffice">Torna-ho a provar <RefreshCw size={14} aria-hidden="true" /></button>}
              {kind === 'restricted' && <a className="bo-action" href={`${import.meta.env.BASE_URL.replace(/\/$/, '')}/`} data-testid="link-restricted-home">Torna a la inscripció <ArrowRight size={15} aria-hidden="true" /></a>}
            </>
          )}
        </section>
      </main>
    </PageFrame>
  );
}

function Metric({ index, label, amount, testId }: { index: string; label: string; amount: number; testId: string }) {
  return (
    <div className="bo-metric">
      <span className="bo-metric-number">{index} / 05</span>
      <div>
        <div className="bo-metric-label">{label}</div>
        <div className="bo-metric-value" data-testid={testId}>{money(amount)}</div>
      </div>
    </div>
  );
}

function Summary({ summary }: { summary: BackofficeSummary }) {
  return (
    <section aria-labelledby="bo-summary-title">
      <div className="bo-section-heading"><h2 id="bo-summary-title">Ingressos confirmats</h2></div>
      <div className="bo-metrics">
        <Metric index="01" label="Total cobrat" amount={summary.totalCents} testId="text-confirmed-total" />
        <Metric index="02" label="Inscripcions" amount={summary.registrationCents} testId="text-registration-revenue" />
        <Metric index="03" label="Allotjament" amount={summary.accommodationCents} testId="text-accommodation-revenue" />
        <Metric index="04" label="Llicències temporals" amount={summary.temporaryLicenseCents} testId="text-license-revenue" />
        <Metric index="05" label="Assegurança de cancel·lació" amount={summary.cancellationInsuranceCents} testId="text-insurance-revenue" />
      </div>
      {(summary.discountCents ?? 0) > 0 && (
        <div className="bo-legacy"><span>Descomptes aplicats sobre el total</span><strong data-testid="text-discount-revenue">{money(-summary.discountCents!)}</strong></div>
      )}
      {summary.legacyOtherCents !== 0 && (
        <div className="bo-legacy"><span>Altres imports històrics inclosos en el total</span><strong data-testid="text-legacy-revenue">{money(summary.legacyOtherCents)}</strong></div>
      )}
      {summary.unallocatedCents !== 0 && (
        <div className="bo-legacy" role="status"><span>Cobraments confirmats pendents de desglossar; inclosos al total global, no als conceptes</span><strong>{money(summary.unallocatedCents)}</strong></div>
      )}
    </section>
  );
}

export default function BackofficePage() {
  const { isLoaded, isSignedIn, userId } = useAuth();
  const reportQuery = useGetBackofficeReport({
    query: {
      queryKey: [...getGetBackofficeReportQueryKey(), userId],
      enabled: isLoaded && Boolean(isSignedIn && userId),
      refetchInterval: isSignedIn ? 30_000 : false,
      retry: (failureCount, error) => statusCode(error) !== 403 && statusCode(error) !== 401 && failureCount < 2,
    },
    request: { credentials: 'include' },
  });

  useEffect(() => { document.title = 'Registre privat · Cadí Challenge'; }, []);

  if (!isLoaded) return <AccessState kind="loading" />;
  if (!isSignedIn) return <AccessState kind="signed-out" />;
  if (reportQuery.error && (statusCode(reportQuery.error) === 403 || statusCode(reportQuery.error) === 401)) return <AccessState kind="restricted" />;
  if (reportQuery.isPending) return <AccessState kind="loading" />;
  if (!reportQuery.data) return <AccessState kind="error" onRetry={() => { void reportQuery.refetch(); }} />;

  const report = reportQuery.data;
  return (
    <PageFrame>
      <section className="bo-hero">
        <div className="bo-hero-inner">
          <span className="bo-overline">Cadí Challenge 2027 / Control d’inscripcions</span>
          <div className="bo-title-row">
            <div>
              <h1 className="bo-title">El registre<em>.</em></h1>
              <p className="bo-description">Una vista privada de cada inscripció i dels imports realment cobrats. Les comandes pendents i cancel·lades continuen visibles al llistat.</p>
            </div>
            <div className="bo-hero-meta">
              <span>Última actualització</span>
              <strong data-testid="text-report-updated-at">{dateLabel(report.updatedAt)}</strong>
            </div>
          </div>
        </div>
      </section>
      <main className="bo-content">
        {report.paymentSyncStatus === 'degraded' && (
          <div className="bo-notice" role="alert" data-testid="status-payment-sync-degraded">
            <CircleAlert size={17} aria-hidden="true" />
            <div><strong>Hi ha pagaments que necessiten revisió.</strong>Es mostren els estats i imports guardats. Redsys confirma els cobraments mitjançant notificacions del banc; la verificació automàtica de l’antiga passarel·la està desactivada. Comprova els pagaments històrics o amb incidències abans de prendre decisions.</div>
          </div>
        )}
        {reportQuery.isError && <div className="bo-notice" role="alert" data-testid="status-report-refresh-error"><CircleAlert size={17} aria-hidden="true" /><div><strong>No s’ha pogut actualitzar el registre.</strong>Es mostren les últimes dades recuperades. Torna-ho a provar.</div></div>}
        <Summary summary={report.summary} />
        <section className="bo-ledger" aria-labelledby="bo-ledger-title">
          <div className="bo-ledger-top">
            <div>
              <div className="bo-section-heading"><h2>Detall de la cursa</h2></div>
              <h3 className="bo-ledger-title" id="bo-ledger-title">Inscripcions</h3>
              <p className="bo-ledger-desc">Una fila per participant. Ordena les files, configura les columnes i descarrega el llistat en Excel.</p>
            </div>
            <div className="bo-ledger-actions">
              <span className="bo-count" data-testid="text-registration-count">{report.registrations.length} {report.registrations.length === 1 ? 'inscripció' : 'inscripcions'}</span>
              <button className="bo-refresh" type="button" disabled={reportQuery.isFetching} onClick={() => { void reportQuery.refetch(); }} data-testid="button-refresh-report">
                <RefreshCw aria-hidden="true" /> {reportQuery.isFetching ? 'Actualitzant…' : 'Actualitza'}
              </button>
            </div>
          </div>
          {report.registrations.length === 0 ? (
            <div className="bo-state" data-testid="state-backoffice-empty">
              <div className="bo-state-icon"><ShieldCheck size={21} /></div>
              <h1>Encara no hi ha inscripcions.</h1>
              <p>Quan arribi la primera inscripció, les dades del participant apareixeran aquí. Els imports de dalt només reflecteixen pagaments confirmats.</p>
            </div>
          ) : <BackofficeLedger key={userId} userId={userId!} registrations={report.registrations} />}
          <div className="bo-footnote">
            <span>Imports en EUR · Resum: només pagaments confirmats</span>
            <span>Desplaça la taula per consultar totes les columnes →</span>
          </div>
        </section>
      </main>
    </PageFrame>
  );
}