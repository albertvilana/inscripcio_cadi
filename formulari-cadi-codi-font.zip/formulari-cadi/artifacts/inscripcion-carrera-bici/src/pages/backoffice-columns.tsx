import type { BackofficeRegistration } from '@workspace/api-client-react';

export type ColumnKey = keyof BackofficeRegistration;
export type Column = { key: ColumnKey; label: string; numeric?: boolean };
export const columns: Column[] = [
  { key: 'orderNumber', label: 'Núm. de comanda' },
  { key: 'firstName', label: 'Nom' },
  { key: 'lastName', label: 'Cognoms' },
  { key: 'jerseyCut', label: 'Mallot' },
  { key: 'jerseySize', label: 'Talla' },
  { key: 'accommodation', label: 'Allotjament' },
  { key: 'phone', label: 'Telèfon' },
  { key: 'email', label: 'Correu electrònic' },
  { key: 'paymentStatus', label: 'Estat del pagament' },
  { key: 'paidTotalCents', label: 'Total pagat', numeric: true },
  { key: 'registrationAmountCents', label: 'Inscripció', numeric: true },
  { key: 'accommodationAmountCents', label: 'Allotjament €', numeric: true },
  { key: 'temporaryLicenseAmountCents', label: 'Llicència temporal', numeric: true },
  { key: 'cancellationInsuranceAmountCents', label: 'Assegurança de cancel·lació', numeric: true },
  { key: 'legacyOtherAmountCents', label: 'Altres imports històrics', numeric: true },
  { key: 'orderTotalCents', label: 'Total de la comanda', numeric: true },
  { key: 'createdAt', label: 'Data d’inscripció' },
];
const currency = new Intl.NumberFormat('ca-ES', { style: 'currency', currency: 'EUR' });
const dateTime = new Intl.DateTimeFormat('ca-ES', { dateStyle: 'medium', timeStyle: 'short' });
export const collator = new Intl.Collator('ca', { numeric: true, sensitivity: 'base' });
export const money = (cents: number) => currency.format(cents / 100);
export const dateLabel = (value: string) => {
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? '—' : dateTime.format(parsed);
};
const accommodationLabel = { none: 'Sense allotjament', saturday: 'Dissabte', sunday: 'Diumenge', both: 'Dissabte i diumenge' };
const statusLabel = { pending: 'Pendent', paid: 'Pagat', cancelled: 'Cancel·lat' };

// Plain typed values for Excel: never interpret participant strings as formulas.
export function exportValue(row: BackofficeRegistration, key: ColumnKey): string | number {
  if (key === 'jerseyCut') return row.jerseyCut === 'men' ? 'Home' : row.jerseyCut === 'women' ? 'Dona' : '—';
  if (key === 'accommodation') return accommodationLabel[row.accommodation];
  if (key === 'paymentStatus') return statusLabel[row.paymentStatus];
  if (key === 'createdAt') return dateLabel(row.createdAt);
  if (key.endsWith('Cents')) return (row[key] as number) / 100;
  return String(row[key] ?? '');
}
export function cellContent(row: BackofficeRegistration, key: ColumnKey) {
  if (key === 'orderNumber') return <span>{row.orderNumber}{!row.breakdownVerified && <small className="bo-estimate" title="El desglossament d'aquesta comanda antiga és una estimació, no un import verificat">Estimat</small>}</span>;
  if (key === 'paymentStatus') return <span className={`bo-status bo-status-${row.paymentStatus}`}>{statusLabel[row.paymentStatus]}</span>;
  if (key.endsWith('Cents')) return money(row[key] as number);
  return exportValue(row, key);
}
export function compareRows(a: BackofficeRegistration, b: BackofficeRegistration, key: ColumnKey) {
  const left = a[key], right = b[key];
  if (left == null && right == null) return 0;
  if (left == null) return -1;
  if (right == null) return 1;
  if (key === 'createdAt') return (Date.parse(String(left)) || 0) - (Date.parse(String(right)) || 0);
  if (typeof left === 'number' && typeof right === 'number') return left - right;
  return collator.compare(String(left), String(right));
}