import { Router, type IRouter } from "express";
import { getAuth } from "@clerk/express";
import { Readable } from "node:stream";
import {
  RequestUploadUrlBody,
  RequestUploadUrlResponse,
  ConfirmLicensePhotoBody,
  ConfirmLicensePhotoResponse,
} from "@workspace/api-zod";
import { ObjectNotFoundError, ObjectStorageService } from "../lib/objectStorage";
import { ObjectPermission } from "../lib/objectAcl";
import { db, licenseUploadsTable } from "@workspace/db";
import { and, eq, gt, isNull } from "drizzle-orm";
import { redsysPaymentsEnabled } from "../lib/redsys";

const router: IRouter = Router();
const storage = new ObjectStorageService();
const allowedTypes = new Set(["image/jpeg", "image/png", "image/webp"]);
const maxBytes = 5 * 1024 * 1024;

router.post("/storage/uploads/request-url", async (req, res) => {
  if (!redsysPaymentsEnabled()) {
    res.status(503).json({ error: "La subida de licencias está desactivada en esta vista previa." });
    return;
  }
  const owner = getAuth(req).userId;
  if (!owner) {
    res.status(401).json({ error: "Inicia sesión para subir tu licencia." });
    return;
  }
  const parsed = RequestUploadUrlBody.safeParse(req.body);
  if (!parsed.success || !allowedTypes.has(parsed.data.contentType) || parsed.data.size > maxBytes) {
    res.status(400).json({ error: "Elige una foto JPG, PNG o WebP de hasta 5 MB." });
    return;
  }
  try {
    const uploadURL = await storage.getObjectEntityUploadURL();
    const objectPath = storage.normalizeObjectEntityPath(uploadURL);
    await db.insert(licenseUploadsTable).values({
      objectPath,
      ownerId: owner,
      expiresAt: new Date(Date.now() + 15 * 60 * 1000),
    });
    res.json(RequestUploadUrlResponse.parse({ uploadURL, objectPath }));
  } catch (err) {
    req.log.error({ err }, "Unable to request license upload URL");
    res.status(503).json({ error: "No se ha podido preparar la subida. Inténtalo de nuevo." });
  }
});

router.post("/storage/uploads/confirm", async (req, res) => {
  if (!redsysPaymentsEnabled()) {
    res.status(503).json({ error: "La subida de licencias está desactivada en esta vista previa." });
    return;
  }
  const owner = getAuth(req).userId;
  if (!owner) {
    res.status(401).json({ error: "Inicia sesión para confirmar tu licencia." });
    return;
  }
  const parsed = ConfirmLicensePhotoBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Falta la foto de la licencia." });
    return;
  }
  const { objectPath } = parsed.data;
  const [attempt] = await db.select({ objectPath: licenseUploadsTable.objectPath })
    .from(licenseUploadsTable)
    .where(and(
      eq(licenseUploadsTable.objectPath, objectPath),
      eq(licenseUploadsTable.ownerId, owner),
      gt(licenseUploadsTable.expiresAt, new Date()),
      isNull(licenseUploadsTable.confirmedAt),
    ));
  if (!attempt) {
    res.status(403).json({ error: "La subida ha caducado. Vuelve a elegir la foto." });
    return;
  }
  try {
    const file = await storage.getObjectEntityFile(objectPath);
    const [metadata] = await file.getMetadata();
    if (!allowedTypes.has(metadata.contentType ?? "") || Number(metadata.size) > maxBytes || Number(metadata.size) < 1) {
      res.status(400).json({ error: "Elige una foto JPG, PNG o WebP de hasta 5 MB." });
      return;
    }
    await storage.trySetObjectEntityAclPolicy(objectPath, { owner, visibility: "private" });
    // Consume the grant atomically but retain the upload record for cleanup.
    const [consumed] = await db.update(licenseUploadsTable)
      .set({ confirmedAt: new Date() })
      .where(and(
        eq(licenseUploadsTable.objectPath, objectPath),
        eq(licenseUploadsTable.ownerId, owner),
        gt(licenseUploadsTable.expiresAt, new Date()),
        isNull(licenseUploadsTable.confirmedAt),
      ))
      .returning({ objectPath: licenseUploadsTable.objectPath });
    if (!consumed) {
      res.status(403).json({ error: "La subida ha caducado. Vuelve a elegir la foto." });
      return;
    }
    res.json(ConfirmLicensePhotoResponse.parse({ objectPath }));
  } catch (err) {
    req.log.warn({ err }, "License upload could not be confirmed");
    res.status(400).json({ error: "No se ha recibido la foto. Vuelve a subirla." });
  }
});

// Public assets live outside PRIVATE_OBJECT_DIR. License photos are never served here.
router.get("/storage/public-objects/*filePath", async (req, res) => {
  try {
    const raw = req.params.filePath;
    const file = await storage.searchPublicObject(Array.isArray(raw) ? raw.join("/") : raw);
    if (!file) {
      res.status(404).json({ error: "Archivo no encontrado." });
      return;
    }
    const response = await storage.downloadObject(file);
    res.status(response.status);
    response.headers.forEach((value, key) => res.setHeader(key, value));
    if (response.body) Readable.fromWeb(response.body as ReadableStream<Uint8Array>).pipe(res);
    else res.end();
  } catch (err) {
    req.log.error({ err }, "Unable to serve public object");
    res.status(500).json({ error: "No se ha podido abrir el archivo." });
  }
});

router.get("/storage/objects/*path", async (req, res) => {
  const owner = getAuth(req).userId;
  if (!owner) {
    res.status(401).json({ error: "Inicia sesión para consultar esta foto." });
    return;
  }
  try {
    const raw = req.params.path;
    const objectPath = `/objects/${Array.isArray(raw) ? raw.join("/") : raw}`;
    const file = await storage.getObjectEntityFile(objectPath);
    const allowed = await storage.canAccessObjectEntity({
      userId: owner,
      objectFile: file,
      requestedPermission: ObjectPermission.READ,
    });
    if (!allowed) {
      res.status(403).json({ error: "No tienes acceso a este archivo." });
      return;
    }
    const response = await storage.downloadObject(file, 0);
    res.status(response.status);
    response.headers.forEach((value, key) => res.setHeader(key, value));
    res.setHeader("Cache-Control", "private, no-store");
    if (response.body) Readable.fromWeb(response.body as ReadableStream<Uint8Array>).pipe(res);
    else res.end();
  } catch (err) {
    if (err instanceof ObjectNotFoundError) {
      res.status(404).json({ error: "Foto no encontrada." });
      return;
    }
    req.log.error({ err }, "Unable to serve private license");
    res.status(500).json({ error: "No se ha podido abrir la foto." });
  }
});

export default router;