import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { getAuth } from "@clerk/express";
import { and, desc, eq, isNotNull } from "drizzle-orm";
import { Readable } from "node:stream";
import {
  GetOrganizerAccessResponse,
  ListOrganizerRegistrationsResponse,
  ListOrganizerMembersResponse,
  SaveOrganizerMemberBody,
  SaveOrganizerMemberResponse,
  GetOrganizerLicenseParams,
  RemoveOrganizerMemberParams,
} from "@workspace/api-zod";
import { db, organizersTable, registrationsTable } from "@workspace/db";
import { ObjectNotFoundError, ObjectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();
const storage = new ObjectStorageService();

// The bootstrap admin must be configured server-side; no authenticated user
// can claim this role through a public endpoint.
function isBootstrapAdmin(userId: string): boolean {
  return (process.env.ORGANIZER_ADMIN_USER_IDS ?? "")
    .split(",")
    .map((id) => id.trim())
    .filter(Boolean)
    .includes(userId);
}

async function roleFor(userId: string): Promise<"admin" | "reviewer" | null> {
  if (isBootstrapAdmin(userId)) return "admin";
  const [member] = await db.select({ role: organizersTable.role })
    .from(organizersTable).where(eq(organizersTable.userId, userId));
  return member?.role === "admin" || member?.role === "reviewer" ? member.role : null;
}

async function requireRole(req: Request, res: Response, next: NextFunction): Promise<void> {
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Inicia sesión para acceder a la organización." });
    return;
  }
  const role = await roleFor(userId);
  if (!role) {
    res.status(403).json({ error: "Tu cuenta no tiene acceso al equipo organizador." });
    return;
  }
  res.locals.organizerRole = role;
  next();
}

function requireAdmin(_req: Request, res: Response, next: NextFunction): void {
  if (res.locals.organizerRole !== "admin") {
    res.status(403).json({ error: "Solo la administración puede gestionar el equipo." });
    return;
  }
  next();
}

router.get("/organization/me", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "private, no-store");
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Inicia sesión para acceder a la organización." });
    return;
  }
  res.json(GetOrganizerAccessResponse.parse({ userId, role: await roleFor(userId) }));
});

router.get("/organization/registrations", requireRole, async (_req, res): Promise<void> => {
  res.setHeader("Cache-Control", "private, no-store");
  const rows = await db.select({
    id: registrationsTable.id,
    firstName: registrationsTable.firstName,
    lastName: registrationsTable.lastName,
    createdAt: registrationsTable.createdAt,
    status: registrationsTable.status,
  }).from(registrationsTable)
    .where(and(eq(registrationsTable.hasCyclingLicense, true), isNotNull(registrationsTable.licensePhotoPath)))
    .orderBy(desc(registrationsTable.createdAt));
  res.json(ListOrganizerRegistrationsResponse.parse(rows));
});

router.get("/organization/registrations/:id/license", requireRole, async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "private, no-store");
  res.setHeader("X-Content-Type-Options", "nosniff");
  const parsed = GetOrganizerLicenseParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Referencia de inscripción no válida." });
    return;
  }
  const [row] = await db.select({ path: registrationsTable.licensePhotoPath })
    .from(registrationsTable)
    .where(and(eq(registrationsTable.id, parsed.data.id), eq(registrationsTable.hasCyclingLicense, true)));
  if (!row?.path || !/^\/objects\/uploads\/[0-9a-f-]{36}$/.test(row.path)) {
    res.status(404).json({ error: "No hay foto asociada a esta inscripción." });
    return;
  }
  try {
    const file = await storage.getObjectEntityFile(row.path);
    const [metadata] = await file.getMetadata();
    if (!["image/jpeg", "image/png", "image/webp"].includes(metadata.contentType ?? "")) {
      res.status(415).json({ error: "El archivo no es una imagen compatible." });
      return;
    }
    const response = await storage.downloadObject(file, 0);
    res.status(response.status);
    res.setHeader("Content-Type", metadata.contentType!);
    res.setHeader("Content-Disposition", "inline");
    if (metadata.size) res.setHeader("Content-Length", String(metadata.size));
    if (response.body) Readable.fromWeb(response.body as ReadableStream<Uint8Array>).pipe(res);
    else res.end();
  } catch (err) {
    if (err instanceof ObjectNotFoundError) {
      res.status(404).json({ error: "Foto no encontrada." });
      return;
    }
    req.log.error({ err }, "Unable to serve organizer license");
    res.status(500).json({ error: "No se ha podido abrir la foto." });
  }
});

router.get("/organization/members", requireRole, requireAdmin, async (_req, res): Promise<void> => {
  res.setHeader("Cache-Control", "private, no-store");
  const members = await db.select({ userId: organizersTable.userId, role: organizersTable.role })
    .from(organizersTable).orderBy(organizersTable.createdAt);
  res.json(ListOrganizerMembersResponse.parse(members));
});

router.put("/organization/members", requireRole, requireAdmin, async (req, res): Promise<void> => {
  const parsed = SaveOrganizerMemberBody.safeParse(req.body);
  if (!parsed.success || !/^user_[A-Za-z0-9]+$/.test(parsed.data.userId)) {
    res.status(400).json({ error: "Indica un ID de usuario válido y un rol." });
    return;
  }
  const { userId, role } = parsed.data;
  if (isBootstrapAdmin(userId)) {
    res.status(400).json({ error: "El rol de la cuenta inicial se configura en el servidor." });
    return;
  }
  await db.insert(organizersTable).values({ userId, role })
    .onConflictDoUpdate({ target: organizersTable.userId, set: { role } });
  res.setHeader("Cache-Control", "private, no-store");
  res.json(SaveOrganizerMemberResponse.parse({ userId, role }));
});

router.delete("/organization/members/:userId", requireRole, requireAdmin, async (req, res): Promise<void> => {
  const parsed = RemoveOrganizerMemberParams.safeParse(req.params);
  if (!parsed.success || isBootstrapAdmin(parsed.data.userId)) {
    res.status(400).json({ error: "No se puede revocar esta cuenta." });
    return;
  }
  await db.delete(organizersTable).where(eq(organizersTable.userId, parsed.data.userId));
  res.setHeader("Cache-Control", "private, no-store");
  res.sendStatus(204);
});

export default router;