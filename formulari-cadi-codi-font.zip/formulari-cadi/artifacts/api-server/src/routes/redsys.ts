import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, registrationsTable } from "@workspace/db";
import { GetRegistrationPaymentParams, GetRegistrationPaymentResponse } from "@workspace/api-zod";
import { getRedsysConfig, redsysOrder, redsysPaymentOutcome, verifyRedsysNotification } from "../lib/redsys";

export function createRedsysRouter(configProvider = getRedsysConfig): IRouter {
const router: IRouter = Router();

// No browser return URL may change payment state. Only a verified bank notification can.
router.post("/redsys/notification", async (req, res): Promise<void> => {
  const config = configProvider();
  if (!config) {
    res.sendStatus(503);
    return;
  }
  let notification;
  try {
    notification = verifyRedsysNotification(req.body, config);
  } catch {
    // Never log request parameters, bank signatures, or customer/payment data.
    res.sendStatus(400);
    return;
  }
  if (!notification.order.startsWith("2027")) {
    res.sendStatus(400);
    return;
  }
  const sequence = Number(notification.order.slice(4));
  if (!Number.isSafeInteger(sequence) || sequence < 1 || sequence > 6759324 ||
      redsysOrder(sequence) !== notification.order) {
    res.sendStatus(400);
    return;
  }
  const result = await db.transaction(async (tx) => {
    const [registration] = await tx.select().from(registrationsTable)
      .where(eq(registrationsTable.orderNumberSequence, sequence)).for("update");
    if (!registration) return 404;
    const outcome = redsysPaymentOutcome(registration, notification);
    if (outcome === "wrong-provider") return 404;
    if (outcome === "mismatch") {
      await tx.update(registrationsTable).set({
        paymentIssue: "Redsys: el importe o la moneda no coincide con la inscripción.",
        paymentCheckedAt: new Date(),
      }).where(eq(registrationsTable.id, registration.id));
      return 400;
    }
    // Retries are idempotent. A delayed failure must never undo a confirmed payment.
    if (outcome === "already-paid") return 200;
    await tx.update(registrationsTable).set(outcome === "paid" ? {
      status: "paid",
      paidTotalCents: notification.amountCents,
      paidAt: new Date(),
      paymentCheckedAt: new Date(),
      paymentIssue: null,
    } : {
      status: "cancelled",
      paymentCheckedAt: new Date(),
      paymentIssue: `Redsys: operación no autorizada (${notification.responseCode}).`,
    }).where(eq(registrationsTable.id, registration.id));
    return 200;
  });
  res.status(result).type("text/plain").send(result === 200 ? "OK" : "Payment not accepted");
});

// UUID is the guest's unguessable receipt reference; never return personal information.
router.get("/registrations/:registrationId/payment", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  const parsed = GetRegistrationPaymentParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "Referencia no válida." });
    return;
  }
  const [registration] = await db.select({
    status: registrationsTable.status,
    paidTotalCents: registrationsTable.paidTotalCents,
    orderTotalCents: registrationsTable.orderTotalCents,
  }).from(registrationsTable).where(eq(registrationsTable.id, parsed.data.registrationId));
  if (!registration) {
    res.status(404).json({ error: "Inscripción no encontrada." });
    return;
  }
  res.json(GetRegistrationPaymentResponse.parse(registration));
});

return router;
}

export default createRedsysRouter();
