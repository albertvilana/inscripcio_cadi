import { Router, type IRouter } from "express";
import { desc } from "drizzle-orm";
import { GetBackofficeReportResponse } from "@workspace/api-zod";
import { db, registrationsTable, type Registration } from "@workspace/db";
import { racePricing } from "../lib/racePricing";
import { needsHistoricalPaymentReview } from "../lib/paymentReview";
import { requireOrganizer } from "../lib/requireOrganizer";
import { formatOrderNumber } from "../lib/orderNumber";

const router: IRouter = Router();

function breakdownFor(registration: Registration) {
  const registrationAmountCents = registration.registrationAmountCents ?? racePricing.registration;
  const accommodationAmountCents = registration.accommodationAmountCents ??
    ((registration.accommodation === "saturday" || registration.accommodation === "both" ? racePricing.accommodationDay : 0) +
      (registration.accommodation === "sunday" || registration.accommodation === "both" ? racePricing.accommodationDay : 0));
  const temporaryLicenseAmountCents = registration.temporaryLicenseAmountCents ??
    (registration.hasCyclingLicense === false ? racePricing.temporaryLicense : 0);
  const cancellationInsuranceAmountCents = registration.cancellationInsuranceAmountCents ??
    (registration.cancellationInsurance ? racePricing.cancellationInsurance : 0);
  const orderTotalCents = registration.orderTotalCents ?? Math.round(registration.total * 100);
  const discountAmountCents = registration.discountAmountCents ?? 0;
  // Older orders can contain the discontinued accident-insurance item. Keep its
  // historical value visible rather than attributing it to a current product.
  const legacyOtherAmountCents = orderTotalCents + discountAmountCents -
    registrationAmountCents - accommodationAmountCents -
    temporaryLicenseAmountCents - cancellationInsuranceAmountCents;
  return {
    registrationAmountCents, accommodationAmountCents,
    temporaryLicenseAmountCents, cancellationInsuranceAmountCents,
    legacyOtherAmountCents, orderTotalCents, discountAmountCents,
  };
}

router.get("/backoffice/report", async (req, res): Promise<void> => {
  if (!await requireOrganizer(req, res)) return;

  const rows = await db.select().from(registrationsTable).orderBy(desc(registrationsTable.createdAt));
  // The retired payment provider is not contacted. Keep persisted confirmations
  // and amounts intact; flag anything that still needs an organizer's review.
  const paymentSyncStatus = rows.some(needsHistoricalPaymentReview) ? "degraded" : "ok";
  const summary = {
    discountCents: 0,
    registrationCents: 0,
    accommodationCents: 0,
    temporaryLicenseCents: 0,
    cancellationInsuranceCents: 0,
    legacyOtherCents: 0,
    unallocatedCents: 0,
    totalCents: 0,
  };
  const registrations = rows.map((row) => {
    const breakdown = breakdownFor(row);
    const breakdownVerified = row.registrationAmountCents !== null &&
      row.accommodationAmountCents !== null &&
      row.temporaryLicenseAmountCents !== null &&
      row.cancellationInsuranceAmountCents !== null;
    // Count revenue only once per verified order, never once per checkout attempt.
    if (row.status === "paid" && row.paidTotalCents === breakdown.orderTotalCents) {
      if (breakdownVerified) {
        summary.registrationCents += breakdown.registrationAmountCents;
        summary.accommodationCents += breakdown.accommodationAmountCents;
        summary.temporaryLicenseCents += breakdown.temporaryLicenseAmountCents;
        summary.cancellationInsuranceCents += breakdown.cancellationInsuranceAmountCents;
        summary.legacyOtherCents += breakdown.legacyOtherAmountCents;
        summary.discountCents += breakdown.discountAmountCents;
      } else {
        summary.unallocatedCents += row.paidTotalCents;
      }
      summary.totalCents += row.paidTotalCents;
    }
    return {
      orderNumber: formatOrderNumber(row.orderNumberSequence),
      paidTotalCents: row.status === "paid" ? row.paidTotalCents ?? 0 : 0,
      ...breakdown,
      breakdownVerified,
      firstName: row.firstName,
      lastName: row.lastName,
      jerseyCut: row.jerseyCut === "men" || row.jerseyCut === "women" ? row.jerseyCut : null,
      jerseySize: row.jerseySize,
      accommodation: row.accommodation,
      phone: row.phone,
      email: row.email,
      paymentStatus: row.status === "paid" || row.status === "cancelled" ? row.status : "pending",
      createdAt: row.createdAt.toISOString(),
    };
  });
  res.set("Cache-Control", "private, no-store");
  res.json(GetBackofficeReportResponse.parse({
    summary, registrations, updatedAt: new Date().toISOString(), paymentSyncStatus,
  }));
});

export default router;