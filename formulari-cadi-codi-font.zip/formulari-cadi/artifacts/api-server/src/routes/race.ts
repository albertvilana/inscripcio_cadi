import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import {
  CreateRegistrationBody,
  CreateRegistrationResponse,
  GetRaceResponse,
  ValidateDiscountCodeBody,
  ValidateDiscountCodeResponse,
  CreateCheckoutSessionBody,
  CreateCheckoutSessionResponse,
} from "@workspace/api-zod";
import { db, licenseUploadsTable, registrationsTable } from "@workspace/db";
import { randomUUID } from "node:crypto";
import { getAuth } from "@clerk/express";
import { ObjectStorageService } from "../lib/objectStorage";
import { ObjectPermission } from "../lib/objectAcl";
import { calculateRaceBreakdown, racePricing } from "../lib/racePricing";
import { DiscountCodeError, resolveDiscountCode } from "../lib/discountCodes";
import { LICENSE_PHOTO_RETENTION_MS } from "../lib/licenseCleanup";
import { createRedsysFields, getRedsysConfig, redsysOrder, redsysPaymentsEnabled } from "../lib/redsys";

const router: IRouter = Router();
const storage = new ObjectStorageService();

class LicensePhotoError extends Error {
  constructor(message: string, readonly status: number) {
    super(message);
  }
}

function isPaymentTransitionPaused(): boolean {
  return !redsysPaymentsEnabled();
}

const race = {
  id: "specilized-cadi-challenge-2027",
  name: "Specilized Cadí Challenge",
  edition: "11ª Ediciò",
  dates: "5–6 de junio de 2027",
  location: "Bellver de Cerdanya",
  tagline: "Ciclisme d'experiència",
  basePrice: racePricing.registration / 100,
  registrationStatus: "paused",
  currency: "EUR",
  options: [
    {
      id: "accommodation-saturday",
      label: "Alojamiento y pensión completa · sábado 5",
      description: "Alojamiento y pensión completa del sábado 5 de junio de 2027",
      price: racePricing.accommodationDay / 100,
      kind: "accommodation",
    },
    {
      id: "accommodation-sunday",
      label: "Alojamiento y pensión completa · domingo 6",
      description: "Alojamiento y pensión completa del domingo 6 de junio de 2027",
      price: racePricing.accommodationDay / 100,
      kind: "accommodation",
    },
    {
      id: "temporary-license",
      label: "Licencia temporal para dos días",
      description: "Para participantes sin licencia de ciclismo",
      price: racePricing.temporaryLicense / 100,
      kind: "license",
    },
    {
      id: "cancellation-insurance",
      label: "Seguro de cancelación",
      description: "Recupera el importe íntegramente hasta 2 meses antes de participar y el 50% hasta 2 semanas antes de empezar",
      price: racePricing.cancellationInsurance / 100,
      kind: "insurance",
    },
  ],
} as const;

router.get("/race", (_req, res): void => {
  res.json(GetRaceResponse.parse({ ...race, registrationStatus: isPaymentTransitionPaused() ? "paused" : "open" }));
});

router.post("/discount-code", (req, res): void => {
  const parsed = ValidateDiscountCodeBody.safeParse(req.body);
  if (!parsed.success || !parsed.data.code.trim()) {
    res.status(400).json({ error: "Introduce un código de descuento." });
    return;
  }
  try {
    const discount = resolveDiscountCode(parsed.data.code)!;
    res.json(ValidateDiscountCodeResponse.parse({
      code: discount.code, amount: discount.amountCents / 100, currency: "EUR",
    }));
  } catch (error) {
    if (!(error instanceof DiscountCodeError)) throw error;
    res.status(400).json({ error: error.message });
  }
});

router.post("/registrations", async (req, res): Promise<void> => {
  if (isPaymentTransitionPaused()) {
    res.status(503).json({ error: "Les inscripcions i els pagaments estan temporalment aturats fins que Redsys estigui configurat." });
    return;
  }
  const parsed = CreateRegistrationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  if (!parsed.data.termsAccepted) {
    res.status(400).json({ error: "Debes aceptar las condiciones de participación." });
    return;
  }

  const { hasCyclingLicense, licensePhotoPath } = parsed.data;
  let licenseOwnerId: string | null = null;
  if (hasCyclingLicense) {
    licenseOwnerId = getAuth(req).userId;
    if (!licenseOwnerId) {
      res.status(401).json({ error: "Inicia sesión para adjuntar tu licencia de ciclismo." });
      return;
    }
    if (!licensePhotoPath?.startsWith("/objects/uploads/")) {
      res.status(400).json({ error: "Adjunta una foto de tu licencia de ciclismo." });
      return;
    }
  } else if (licensePhotoPath) {
    res.status(400).json({ error: "Si no tienes licencia, no debes adjuntar una foto." });
    return;
  }

  let breakdown: ReturnType<typeof calculateRaceBreakdown>;
  try {
    // Never trust a discount amount or a total supplied by the browser.
    breakdown = calculateRaceBreakdown(parsed.data);
  } catch (error) {
    if (!(error instanceof DiscountCodeError)) throw error;
    res.status(400).json({ error: error.message });
    return;
  }
  const registration = {
    id: randomUUID(),
    ...parsed.data,
    discountCode: breakdown.discountCode ?? undefined,
    discountAmount: breakdown.discountAmountCents / 100,
    total: breakdown.orderTotalCents / 100,
    currency: "EUR",
    status: "pending" as const,
  };

  try {
    await db.transaction(async (tx) => {
      if (licensePhotoPath && licenseOwnerId) {
        // Lock the upload before checking the file and saving the registration.
        // Cleanup locks the same row, so neither can delete a photo mid-save.
        const [upload] = await tx.select().from(licenseUploadsTable)
          .where(eq(licenseUploadsTable.objectPath, licensePhotoPath))
          .for("update");
        if (upload && (upload.ownerId !== licenseOwnerId || !upload.confirmedAt)) {
          throw new LicensePhotoError("Confirma la subida de tu propia licencia antes de inscribirte.", 403);
        }
        if (upload && upload.expiresAt.getTime() + LICENSE_PHOTO_RETENTION_MS <= Date.now()) {
          throw new LicensePhotoError("La foto ha caducado. Vuelve a subirla.", 400);
        }
        // A photo confirmed before upload tracking was introduced has no row.
        // It is never a cleanup candidate, but still needs the same ACL check.
        try {
          const file = await storage.getObjectEntityFile(licensePhotoPath);
          const allowed = await storage.canAccessObjectEntity({
            userId: licenseOwnerId,
            objectFile: file,
            requestedPermission: ObjectPermission.READ,
          });
          if (!allowed) throw new LicensePhotoError("No tienes acceso a esta foto de licencia.", 403);
          const [metadata] = await file.getMetadata();
          if (!["image/jpeg", "image/png", "image/webp"].includes(metadata.contentType ?? "") ||
            Number(metadata.size) > 5 * 1024 * 1024 || Number(metadata.size) < 1) {
            throw new LicensePhotoError("La foto de la licencia no es válida.", 400);
          }
        } catch (error) {
          if (error instanceof LicensePhotoError) throw error;
          throw new LicensePhotoError("No se ha podido verificar la foto de tu licencia. Vuelve a subirla.", 400);
        }
      }
      await tx.insert(registrationsTable).values({
        id: registration.id,
        firstName: registration.firstName,
        lastName: registration.lastName,
        email: registration.email,
        phone: registration.phone,
        birthDate: registration.birthDate.toISOString().slice(0, 10),
        nationality: registration.nationality,
        accommodation: registration.accommodation,
        accidentInsurance: false,
        hasCyclingLicense: registration.hasCyclingLicense,
        licensePhotoPath: registration.hasCyclingLicense ? registration.licensePhotoPath : null,
        licenseOwnerId,
        cancellationInsurance: registration.cancellationInsurance,
        jerseyCut: registration.jerseyCut,
        jerseySize: registration.jerseySize,
        notes: registration.notes ?? null,
        termsAccepted: registration.termsAccepted,
        marketingAccepted: registration.marketingAccepted,
        total: registration.total,
        ...breakdown,
        currency: registration.currency,
        status: registration.status,
        paymentProvider: "redsys",
      });
      if (licensePhotoPath && licenseOwnerId) {
        await tx.delete(licenseUploadsTable).where(eq(licenseUploadsTable.objectPath, licensePhotoPath));
      }
    });
  } catch (error) {
    if (error instanceof LicensePhotoError) {
      res.status(error.status).json({ error: error.message });
      return;
    }
    throw error;
  }

  res.status(201).json(CreateRegistrationResponse.parse(registration));
});

router.post("/checkout-session", async (req, res): Promise<void> => {
  const config = getRedsysConfig();
  if (!redsysPaymentsEnabled() || !config) {
    res.status(503).json({ error: "Los pagos están temporalmente desactivados." });
    return;
  }
  const parsed = CreateCheckoutSessionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Referencia de inscripción no válida." });
    return;
  }
  const [registration] = await db.select().from(registrationsTable)
    .where(eq(registrationsTable.id, parsed.data.registrationId));
  if (!registration || registration.paymentProvider !== "redsys") {
    res.status(404).json({ error: "Inscripción de Redsys no encontrada." });
    return;
  }
  if (registration.status === "paid") {
    res.status(409).json({ error: "Esta inscripción ya está pagada. No vuelvas a pagar." });
    return;
  }
  if (!registration.orderTotalCents || registration.currency.toUpperCase() !== "EUR") {
    res.status(409).json({ error: "El importe guardado necesita revisión." });
    return;
  }
  const order = redsysOrder(registration.orderNumberSequence);
  res.setHeader("Cache-Control", "no-store");
  res.status(201).json(CreateCheckoutSessionResponse.parse({
    sessionId: order,
    checkoutUrl: config.checkoutUrl,
    formFields: createRedsysFields(config, order, registration.orderTotalCents, registration.id),
  }));
});

export default router;