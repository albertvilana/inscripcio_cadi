import { Router, type IRouter } from "express";
import healthRouter from "./health";
import raceRouter from "./race";
import storageRouter from "./storage";
import backofficeRouter from "./backoffice";
import organizationRouter from "./organization";
import redsysRouter from "./redsys";

const router: IRouter = Router();

router.use(healthRouter);
router.use(raceRouter);
router.use(redsysRouter);
router.use(storageRouter);
router.use(backofficeRouter);
router.use(organizationRouter);

export default router;
