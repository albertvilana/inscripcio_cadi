// Provider-independent: this code remains usable when Redsys replaces Stripe.
const discountCodes: Readonly<Record<string, number>> = Object.freeze({
  CADI20: 2000,
});

export class DiscountCodeError extends Error {
  constructor() {
    super("El código de descuento no es válido.");
  }
}

export function resolveDiscountCode(value?: string) {
  const code = value?.trim().toUpperCase() ?? "";
  if (!code) return null;
  if (!Object.hasOwn(discountCodes, code)) throw new DiscountCodeError();
  return { code, amountCents: discountCodes[code] };
}
