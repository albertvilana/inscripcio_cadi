import { createCipheriv, createHmac, timingSafeEqual } from "node:crypto";

export const REDSYS_SIGNATURE_VERSION = "HMAC_SHA512_V2";
export const REDSYS_LIVE_URL = "https://sis.redsys.es/sis/realizarPago";
export const REDSYS_TEST_URL = "https://sis-t.redsys.es:25443/sis/realizarPago";

export type RedsysConfig = {
  merchantCode: string;
  terminal: string;
  secret: string;
  publicUrl: string;
  checkoutUrl: string;
};

export function getRedsysConfig(env = process.env): RedsysConfig | null {
  const merchantCode = env.REDSYS_MERCHANT_CODE?.trim() ?? "";
  const terminal = env.REDSYS_TERMINAL?.trim() ?? "";
  const secret = env.REDSYS_SECRET_KEY?.trim() ?? "";
  const mode = env.REDSYS_ENVIRONMENT;
  if (!/^\d{9}$/.test(merchantCode) || !/^\d{1,3}$/.test(terminal) ||
      secret.length < 16 || !["live", "test"].includes(mode ?? "")) return null;
  try {
    const url = new URL(env.REDSYS_PUBLIC_URL ?? "");
    if (url.protocol !== "https:" || url.username || url.password || url.search || url.hash) return null;
    return {
      merchantCode, terminal, secret,
      publicUrl: url.href.replace(/\/$/, ""),
      checkoutUrl: mode === "live" ? REDSYS_LIVE_URL : REDSYS_TEST_URL,
    };
  } catch {
    return null;
  }
}

export function redsysPaymentsEnabled(env = process.env): boolean {
  return env.REDSYS_ENABLED === "true" && getRedsysConfig(env) !== null;
}

/** Stable, unique bank order per registration. Retrying cannot create another charge. */
export function redsysOrder(sequence: number): string {
  if (!Number.isSafeInteger(sequence) || sequence < 1 || sequence > 6759324) {
    throw new Error("Invalid payment order sequence");
  }
  return `2027${String(sequence).padStart(8, "0")}`;
}

/** Redsys' V2 protocol uses the Base64 AES ciphertext as the HMAC key, not raw bytes. */
export function signRedsysParameters(encoded: string, order: string, secret: string): string {
  if (!/^\d{4}[A-Za-z0-9]{0,8}$/.test(order)) throw new Error("Invalid Redsys order");
  const key = Buffer.from(secret.slice(0, 16).padEnd(16, "0"), "utf8");
  if (key.length !== 16) throw new Error("Invalid Redsys signing key");
  const cipher = createCipheriv("aes-128-cbc", key, Buffer.alloc(16));
  const diversified = Buffer.concat([cipher.update(order, "utf8"), cipher.final()]).toString("base64");
  return createHmac("sha512", diversified).update(encoded).digest("base64url");
}

export function createRedsysFields(config: RedsysConfig, order: string, amountCents: number, registrationId: string) {
  if (!Number.isSafeInteger(amountCents) || amountCents < 1) throw new Error("Invalid payment amount");
  const returnUrl = `${config.publicUrl}/?registration=${encodeURIComponent(registrationId)}`;
  const parameters = {
    DS_MERCHANT_AMOUNT: String(amountCents),
    DS_MERCHANT_ORDER: order,
    DS_MERCHANT_MERCHANTCODE: config.merchantCode,
    DS_MERCHANT_CURRENCY: "978",
    DS_MERCHANT_TRANSACTIONTYPE: "0",
    DS_MERCHANT_TERMINAL: config.terminal,
    DS_MERCHANT_MERCHANTURL: `${config.publicUrl}/api/redsys/notification`,
    DS_MERCHANT_URLOK: `${returnUrl}&payment=success`,
    DS_MERCHANT_URLKO: `${returnUrl}&payment=cancelled`,
    DS_MERCHANT_PRODUCTDESCRIPTION: "Cadi Challenge 2027",
    DS_MERCHANT_CONSUMERLANGUAGE: "001",
  };
  const encoded = Buffer.from(JSON.stringify(parameters)).toString("base64url");
  return {
    Ds_SignatureVersion: REDSYS_SIGNATURE_VERSION,
    Ds_MerchantParameters: encoded,
    Ds_Signature: signRedsysParameters(encoded, order, config.secret),
  };
}

export type RedsysNotification = {
  order: string;
  amountCents: number;
  approved: boolean;
  responseCode: string;
};

export function redsysPaymentOutcome(
  registration: { paymentProvider: string; currency: string; orderTotalCents: number | null; status: string },
  notification: RedsysNotification,
) {
  if (registration.paymentProvider !== "redsys") return "wrong-provider";
  if (registration.currency.toUpperCase() !== "EUR" || registration.orderTotalCents !== notification.amountCents) return "mismatch";
  if (registration.status === "paid") return "already-paid";
  return notification.approved ? "paid" : "cancelled";
}

export function verifyRedsysNotification(body: unknown, config: RedsysConfig): RedsysNotification {
  if (!body || typeof body !== "object") throw new Error("Invalid notification");
  const input = body as Record<string, unknown>;
  const encoded = input.Ds_MerchantParameters;
  const signature = input.Ds_Signature;
  if (input.Ds_SignatureVersion !== REDSYS_SIGNATURE_VERSION ||
      typeof encoded !== "string" || encoded.length > 24000 || !/^[A-Za-z0-9_+/=-]+$/.test(encoded) ||
      typeof signature !== "string" || !/^[A-Za-z0-9_+/-]{86}={0,2}$/.test(signature)) {
    throw new Error("Invalid notification");
  }
  const decoded: unknown = JSON.parse(Buffer.from(encoded, "base64").toString("utf8"));
  if (!decoded || typeof decoded !== "object" || Array.isArray(decoded)) throw new Error("Invalid parameters");
  const fields = new Map(Object.entries(decoded).map(([key, value]) => [key.toLowerCase(), value]));
  const order = fields.get("ds_order");
  if (typeof order !== "string" || !/^\d{12}$/.test(order)) throw new Error("Invalid order");
  const expected = Buffer.from(signRedsysParameters(encoded, order, config.secret), "base64url");
  const actual = Buffer.from(signature, "base64");
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) throw new Error("Invalid signature");
  const response = fields.get("ds_response");
  const amount = fields.get("ds_amount");
  const terminal = fields.get("ds_terminal");
  if (fields.get("ds_merchantcode") !== config.merchantCode ||
      typeof terminal !== "string" || !/^\d{1,3}$/.test(terminal) || Number(terminal) !== Number(config.terminal) ||
      fields.get("ds_currency") !== "978" || fields.get("ds_transactiontype") !== "0" ||
      typeof response !== "string" || !/^\d{4}$/.test(response) ||
      typeof amount !== "string" || !/^\d{1,12}$/.test(amount) || !Number.isSafeInteger(Number(amount)) || Number(amount) < 1) {
    throw new Error("Unexpected payment parameters");
  }
  return { order, amountCents: Number(amount), approved: Number(response) < 100, responseCode: response };
}
