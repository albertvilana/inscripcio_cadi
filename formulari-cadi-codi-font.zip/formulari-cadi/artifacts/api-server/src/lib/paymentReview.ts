import type { Registration } from "@workspace/db";

type HistoricalPayment = Pick<Registration,
  "status" | "paymentIssue" | "paidTotalCents" | "orderTotalCents" | "total" |
  "registrationAmountCents" | "accommodationAmountCents" |
  "temporaryLicenseAmountCents" | "cancellationInsuranceAmountCents" |
  "stripeCheckoutSessionId" | "stripeCheckoutSessionIds"
>;

/** Stored confirmations remain authoritative; never invent a paid status. */
export function needsHistoricalPaymentReview(registration: HistoricalPayment): boolean {
  if (registration.paymentIssue) return true;
  const attempts = new Set([
    ...(registration.stripeCheckoutSessionIds ?? []),
    ...(registration.stripeCheckoutSessionId ? [registration.stripeCheckoutSessionId] : []),
  ]);
  if (attempts.size > 1) return true;
  if (registration.status !== "paid") return attempts.size > 0;
  return registration.paidTotalCents === null ||
    registration.paidTotalCents !== (registration.orderTotalCents ?? Math.round(registration.total * 100)) ||
    registration.registrationAmountCents === null ||
    registration.accommodationAmountCents === null ||
    registration.temporaryLicenseAmountCents === null ||
    registration.cancellationInsuranceAmountCents === null;
}
