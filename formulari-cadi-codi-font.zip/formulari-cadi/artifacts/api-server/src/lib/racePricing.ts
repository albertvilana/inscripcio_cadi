import { resolveDiscountCode } from "./discountCodes";

export const racePricing = {
  registration: 17000,
  accommodationDay: 6500,
  temporaryLicense: 2500,
  cancellationInsurance: 4000,
} as const;

export type RaceSelection = {
  accommodation: "none" | "saturday" | "sunday" | "both";
  hasCyclingLicense: boolean;
  cancellationInsurance: boolean;
  discountCode?: string;
};

export function calculateRaceBreakdown(selection: RaceSelection) {
  const registrationAmountCents = racePricing.registration;
  const accommodationAmountCents =
    (selection.accommodation === "saturday" || selection.accommodation === "both" ? racePricing.accommodationDay : 0) +
    (selection.accommodation === "sunday" || selection.accommodation === "both" ? racePricing.accommodationDay : 0);
  const temporaryLicenseAmountCents = selection.hasCyclingLicense ? 0 : racePricing.temporaryLicense;
  const cancellationInsuranceAmountCents = selection.cancellationInsurance ? racePricing.cancellationInsurance : 0;
  const subtotalCents = registrationAmountCents + accommodationAmountCents +
    temporaryLicenseAmountCents + cancellationInsuranceAmountCents;
  const discount = resolveDiscountCode(selection.discountCode);
  const discountAmountCents = Math.min(discount?.amountCents ?? 0, subtotalCents);

  return {
    discountCode: discount?.code ?? null,
    discountAmountCents,
    registrationAmountCents,
    accommodationAmountCents,
    temporaryLicenseAmountCents,
    cancellationInsuranceAmountCents,
    orderTotalCents: subtotalCents - discountAmountCents,
  };
}