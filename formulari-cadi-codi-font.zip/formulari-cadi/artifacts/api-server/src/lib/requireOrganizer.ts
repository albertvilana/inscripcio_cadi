import { clerkClient, getAuth } from "@clerk/express";
import type { Request, Response } from "express";

/**
 * Authentication by itself does not grant access to participant details.
 * An explicitly allowed, verified organizer email is required as well.
 */
export async function requireOrganizer(req: Request, res: Response): Promise<boolean> {
  // The public API accepts cross-origin requests, but a participant ledger must not.
  const origin = req.get("origin");
  if (origin) {
    try {
      const host = req.get("host");
      const isLocalDevelopment = process.env.NODE_ENV === "development" &&
        (host?.startsWith("localhost:") || host?.startsWith("127.0.0.1:"));
      if (origin !== `https://${host}` && !(isLocalDevelopment && origin === `http://${host}`)) {
        res.status(403).json({ error: "L'accés ha de provenir de la pàgina del back office." });
        return false;
      }
    } catch {
      res.status(403).json({ error: "Origen de la sol·licitud no vàlid." });
      return false;
    }
  }
  const userId = getAuth(req).userId;
  if (!userId) {
    res.status(401).json({ error: "Inicia sessió per accedir al back office." });
    return false;
  }

  const allowed = new Set(
    (process.env.BACKOFFICE_ADMIN_EMAILS ?? "")
      .split(",")
      .map((email) => email.trim().toLowerCase())
      .filter(Boolean),
  );
  if (allowed.size === 0) {
    res.status(403).json({ error: "L'accés d'organització encara no està configurat." });
    return false;
  }

  try {
    const user = await clerkClient.users.getUser(userId);
    const authorized = user.emailAddresses.some(
      (address) => address.verification?.status === "verified" &&
        allowed.has(address.emailAddress.toLowerCase()),
    );
    if (authorized) return true;
  } catch (error) {
    req.log.error({ error }, "Organizer identity could not be verified");
    res.status(503).json({ error: "No es pot verificar l'accés ara mateix." });
    return false;
  }

  res.status(403).json({ error: "Aquest compte no té accés al back office." });
  return false;
}