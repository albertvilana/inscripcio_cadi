const LETTER_COUNT = 26;
const LETTER_SUFFIX_COUNT = LETTER_COUNT * LETTER_COUNT;
const MAX_ORDER_NUMBER = 9999 * LETTER_SUFFIX_COUNT;

/** Encode a positive database sequence without lossy hashing or truncation. */
export function formatOrderNumber(sequence: number): string {
  if (
    !Number.isSafeInteger(sequence) ||
    sequence < 1 ||
    sequence > MAX_ORDER_NUMBER
  ) {
    throw new RangeError(
      `Order number sequence is outside its supported capacity (1-${MAX_ORDER_NUMBER})`,
    );
  }

  const zeroBasedSequence = sequence - 1;
  const digits = Math.floor(zeroBasedSequence / LETTER_SUFFIX_COUNT) + 1;
  const letterPair = zeroBasedSequence % LETTER_SUFFIX_COUNT;
  const firstLetter = String.fromCharCode(
    65 + Math.floor(letterPair / LETTER_COUNT),
  );
  const secondLetter = String.fromCharCode(65 + (letterPair % LETTER_COUNT));

  return `${String(digits).padStart(4, "0")}${firstLetter}${secondLetter}`;
}
