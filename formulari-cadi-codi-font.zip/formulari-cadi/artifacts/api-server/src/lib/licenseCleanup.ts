import { db, licenseUploadsTable, registrationsTable } from "@workspace/db";
import { eq, lt } from "drizzle-orm";
import { ObjectNotFoundError, ObjectStorageService } from "./objectStorage";
import { logger } from "./logger";

// Signed URLs last 15 minutes; abandoned uploads (confirmed or not) are
// retained for a further 24 hours before deletion. Run at startup and hourly.
export const LICENSE_PHOTO_RETENTION_MS = 24 * 60 * 60 * 1000;
const CLEANUP_INTERVAL_MS = 60 * 60 * 1000;
const storage = new ObjectStorageService();

export async function cleanupUnusedLicensePhotos(now = new Date()): Promise<number> {
  const cutoff = new Date(now.getTime() - LICENSE_PHOTO_RETENTION_MS);
  let removed = 0;
  // One short transaction per photo. Row locks coordinate with registration
  // creation, including when multiple API instances run cleanup at once.
  for (let i = 0; i < 100; i++) {
    const outcome = await db.transaction(async (tx) => {
      const [upload] = await tx.select()
        .from(licenseUploadsTable)
        .where(lt(licenseUploadsTable.expiresAt, cutoff))
        .orderBy(licenseUploadsTable.expiresAt)
        .limit(1)
        .for("update", { skipLocked: true });
      if (!upload) return "done";

      const [linked] = await tx.select({ id: registrationsTable.id })
        .from(registrationsTable)
        .where(eq(registrationsTable.licensePhotoPath, upload.objectPath))
        .limit(1);

      if (!linked) {
        try {
          const file = await storage.getObjectEntityFile(upload.objectPath);
          await file.delete();
        } catch (error) {
          // The object may have been removed between the existence check and
          // delete (or never uploaded after the signed URL was requested).
          if (!(error instanceof ObjectNotFoundError) &&
            !(error instanceof Error && "code" in error && error.code === 404)) throw error;
        }
      }
      await tx.delete(licenseUploadsTable).where(eq(licenseUploadsTable.objectPath, upload.objectPath));
      return linked ? "linked" : "removed";
    });
    if (outcome === "done") break;
    if (outcome === "removed") removed++;
  }
  return removed;
}

export function startLicensePhotoCleanup(): void {
  const run = () => {
    void cleanupUnusedLicensePhotos()
      .then((removed) => logger.info({ removed }, "Unused license photo cleanup completed"))
      .catch((err) => logger.error({ err }, "Unused license photo cleanup failed; will retry"));
  };
  run();
  setInterval(run, CLEANUP_INTERVAL_MS).unref();
}