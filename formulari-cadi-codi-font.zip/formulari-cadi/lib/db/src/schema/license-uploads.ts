import { pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const licenseUploadsTable = pgTable("license_uploads", {
  objectPath: text("object_path").primaryKey(),
  ownerId: text("owner_id").notNull(),
  // The signed upload URL expires after 15 minutes. Keep this record after
  // confirmation so an abandoned photo can be removed after the retention window.
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  confirmedAt: timestamp("confirmed_at", { withTimezone: true }),
});

export const insertLicenseUploadSchema = createInsertSchema(licenseUploadsTable);
export type InsertLicenseUpload = z.infer<typeof insertLicenseUploadSchema>;