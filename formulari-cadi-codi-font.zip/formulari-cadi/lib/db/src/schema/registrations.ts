import { pgTable, text, integer, serial, boolean, timestamp, jsonb, check } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const registrationsTable = pgTable("registrations", {
  id: text("id").primaryKey(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  birthDate: text("birth_date").notNull(),
  nationality: text("nationality").notNull(),
  emergencyName: text("emergency_name"),
  emergencyPhone: text("emergency_phone"),
  accommodation: text("accommodation").notNull(),
  accidentInsurance: boolean("accident_insurance").notNull().default(false),
  hasCyclingLicense: boolean("has_cycling_license"),
  licensePhotoPath: text("license_photo_path"),
  licenseOwnerId: text("license_owner_id"),
  cancellationInsurance: boolean("cancellation_insurance").notNull().default(false),
  // Keep nullable so existing registrations remain intact when this field is added.
  jerseyCut: text("jersey_cut"),
  jerseySize: text("jersey_size").notNull(),
  notes: text("notes"),
  termsAccepted: boolean("terms_accepted").notNull().default(false),
  marketingAccepted: boolean("marketing_accepted").notNull().default(false),
  total: integer("total").notNull(),
  discountCode: text("discount_code"),
  discountAmountCents: integer("discount_amount_cents"),
  registrationAmountCents: integer("registration_amount_cents"),
  accommodationAmountCents: integer("accommodation_amount_cents"),
  temporaryLicenseAmountCents: integer("temporary_license_amount_cents"),
  cancellationInsuranceAmountCents: integer("cancellation_insurance_amount_cents"),
  orderTotalCents: integer("order_total_cents"),
  paidTotalCents: integer("paid_total_cents"),
  // Independent of the UUID primary key and payment-provider references.
  orderNumberSequence: serial("order_number_sequence").notNull().unique(),
  paidAt: timestamp("paid_at", { withTimezone: true }),
  paymentCheckedAt: timestamp("payment_checked_at", { withTimezone: true }),
  paymentIssue: text("payment_issue"),
  paymentProvider: text("payment_provider").notNull().default("stripe"),
  currency: text("currency").notNull().default("eur"),
  status: text("status").notNull().default("pending"),
  stripeCheckoutSessionId: text("stripe_checkout_session_id"),
  stripeCheckoutSessionIds: jsonb("stripe_checkout_session_ids").$type<string[]>(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  check(
    "registrations_order_number_sequence_capacity",
    sql`${table.orderNumberSequence} BETWEEN 1 AND 6759324`,
  ),
]);

export const insertRegistrationSchema = createInsertSchema(registrationsTable).omit({
  createdAt: true,
});
export type InsertRegistration = z.infer<typeof insertRegistrationSchema>;
export type Registration = typeof registrationsTable.$inferSelect;